import React from 'react';

interface StatsCardProps {
  title: string;
  value: string | number;
  icon: React.ReactNode;
  subtitle?: string;
  trend?: {
    value: string | number;
    isPositive: boolean;
  };
}

export default function StatsCard({ title, value, icon, subtitle, trend }: StatsCardProps) {
  return (
    <div className="bg-white dark:bg-[#1E293B] border border-slate-100/90 dark:border-slate-800 p-6 rounded-3xl shadow-sm hover:shadow-md dark:shadow-none transition-all duration-300 relative overflow-hidden group" id={`stats_card_${title.toLowerCase().replace(/\s+/g, '_')}`}>
      {/* Decorative hover grid lines */}
      <div className="absolute top-0 right-0 w-24 h-24 bg-indigo-50/40 dark:bg-indigo-950/20 rounded-full blur-2xl group-hover:bg-indigo-100/40 dark:group-hover:bg-indigo-900/30 transition-all duration-300"></div>

      <div className="flex items-center justify-between">
        <div className="space-y-1 text-left">
          <span className="text-[10px] font-black text-slate-400 dark:text-slate-400 uppercase tracking-widest block">{title}</span>
          <div className="text-2xl font-black text-slate-800 dark:text-slate-100 tracking-tight">{value}</div>
        </div>
        <div className="p-3.5 bg-slate-50 dark:bg-slate-850 text-slate-500 dark:text-slate-400 rounded-2xl group-hover:bg-indigo-50 dark:group-hover:bg-indigo-950/40 group-hover:text-indigo-600 dark:group-hover:text-indigo-400 transition-all duration-300 border border-slate-100 dark:border-slate-700/80">
          {icon}
        </div>
      </div>

      {(subtitle || trend) && (
        <div className="mt-4 flex items-center gap-2 text-xs">
          {trend && (
            <span className={`px-2 py-0.5 rounded-full font-bold ${
              trend.isPositive 
                ? 'bg-emerald-50 dark:bg-emerald-950/50 text-emerald-700 dark:text-emerald-400 border border-emerald-100/40' 
                : 'bg-rose-50 dark:bg-rose-950/50 text-rose-700 dark:text-rose-400 border border-rose-100/40'
            }`}>
              {trend.value}
            </span>
          )}
          {subtitle && <span className="text-slate-500 dark:text-slate-400 font-bold">{subtitle}</span>}
        </div>
      )}
    </div>
  );
}
