import React, { useState, useEffect } from 'react';
import { 
  Shield, 
  Key, 
  Mail, 
  User, 
  Building, 
  ArrowRight, 
  CornerDownLeft, 
  Sparkles, 
  CheckCircle2, 
  AlertCircle,
  Flame,
  BarChart3,
  Lightbulb,
  Eye,
  EyeOff,
  HelpCircle,
  Lock,
  Globe,
  Heart,
  BrainCircuit,
  Fingerprint
} from 'lucide-react';
import { Department } from '../types';

interface AuthPagesProps {
  onLoginSuccess: (user: any, token: string) => void;
}

export default function AuthPages({ onLoginSuccess }: AuthPagesProps) {
  const [isRegister, setIsRegister] = useState(false);
  const [isForgot, setIsForgot] = useState(false);
  const [departments, setDepartments] = useState<Department[]>([]);
  
  // Form states
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [departmentId, setDepartmentId] = useState('');
  const [error, setError] = useState('');
  const [success, setSuccess] = useState('');
  const [loading, setLoading] = useState(false);

  // Redesign custom states
  const [activeRole, setActiveRole] = useState<'admin' | 'employee'>('admin');
  const [showPassword, setShowPassword] = useState(false);
  const [rememberMe, setRememberMe] = useState(false);

  useEffect(() => {
    // Fetch departments for dropdown
    fetch('/api/departments')
      .then(res => res.json())
      .then(data => {
        setDepartments(data);
        if (data.length > 0) setDepartmentId(data[0].id);
      })
      .catch(err => console.error('Error fetching departments:', err));
  }, []);

  // Set default credentials on active role change to help user test easily
  useEffect(() => {
    if (!isRegister && !isForgot) {
      if (activeRole === 'admin') {
        setEmail('admin@company.com');
        setPassword('adminpassword');
      } else {
        setEmail('employee@company.com');
        setPassword('employeepassword');
      }
    }
  }, [activeRole, isRegister, isForgot]);

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setLoading(true);

    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, password })
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Login failed');
      }

      onLoginSuccess(data.user, data.token);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      const response = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ name, email, password, departmentId })
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Registration failed');
      }

      // Automatically log user in
      onLoginSuccess(data.user, data.token);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleForgotPassword = async (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setSuccess('');
    setLoading(true);

    try {
      const response = await fetch('/api/auth/forgot-password', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email, newPassword: password })
      });
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.message || 'Reset failed');
      }

      setSuccess('Your password has been reset successfully! You can now log in.');
      setIsForgot(false);
    } catch (err: any) {
      setError(err.message);
    } finally {
      setLoading(false);
    }
  };

  const handleGoogleLogin = () => {
    setSuccess("OAuth Mock Mode: Integrating client account parameters safely. Automatically authorized!");
    setTimeout(() => {
      // Auto-login with selected role
      if (activeRole === 'admin') {
        setEmail('admin@company.com');
        setPassword('adminpassword');
      } else {
        setEmail('employee@company.com');
        setPassword('employeepassword');
      }
      setSuccess("");
    }, 2500);
  };

  return (
    <div className="min-h-screen w-full flex flex-col lg:flex-row bg-[#F8FAFC] font-sans overflow-x-hidden" id="auth_view_root">
      
      {/* ============================================================== */}
      {/* LEFT COLUMN: Split Screen visual with 45% width on desktop */}
      {/* ============================================================== */}
      <div className="w-full lg:w-[45%] bg-gradient-to-br from-slate-950 via-[#1E1B4B] to-[#311042] text-white p-8 lg:p-12 relative overflow-hidden flex flex-col justify-between shrink-0" id="auth_visual_column">
        {/* Animated Background Mesh & Orbs */}
        <div className="absolute inset-0 pointer-events-none opacity-30">
          <div className="absolute top-[-20%] left-[-20%] w-[80%] h-[80%] rounded-full bg-indigo-500 blur-[120px] animate-pulse"></div>
          <div className="absolute bottom-[-20%] right-[-20%] w-[80%] h-[80%] rounded-full bg-purple-600 blur-[120px]"></div>
          {/* Grid lines */}
          <div className="absolute inset-0 bg-[linear-gradient(to_right,#ffffff03_1px,transparent_1px),linear-gradient(to_bottom,#ffffff03_1px,transparent_1px)] bg-[size:24px_24px]"></div>
        </div>

        {/* Top bar with Branding & Badge */}
        <div className="relative z-10 flex items-center justify-between mb-8 lg:mb-0">
          <div className="flex items-center gap-3">
            <div className="p-2.5 bg-indigo-500/10 rounded-xl backdrop-blur-md border border-indigo-400/20 shadow-inner">
              <Shield className="w-6 h-6 text-indigo-400 animate-pulse" />
            </div>
            <div>
              <span className="text-xl font-black tracking-tight bg-gradient-to-r from-indigo-200 to-purple-200 bg-clip-text text-transparent">FeedForward</span>
              <div className="text-[9px] uppercase tracking-widest text-indigo-400 font-extrabold font-mono">HR Intelligence</div>
            </div>
          </div>
          <span className="text-[10px] flex items-center gap-1 bg-emerald-500/10 text-emerald-400 border border-emerald-500/25 px-2.5 py-1 font-bold rounded-full font-mono">
            <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-ping"></span>
            Gemini Core v1.5
          </span>
        </div>

        {/* Project Overview Details */}
        <div className="relative z-10 my-auto py-8 space-y-8 max-w-lg">
          <div className="space-y-4">
            <div className="inline-block px-3 py-1 bg-indigo-500/10 rounded-lg text-indigo-300 font-semibold text-xs tracking-wider uppercase border border-indigo-500/10">
              AI-Powered HR Intelligence Platform
            </div>
            <h1 className="text-3xl lg:text-4xl font-extrabold tracking-tight leading-tight bg-gradient-to-r from-white via-slate-100 to-slate-200">
              AI Employee Feedback Agent
            </h1>
            <p className="text-slate-300 text-sm leading-relaxed max-w-md">
              Transform employee feedback into actionable HR insights using Google Gemini AI. Identify team sentiment, isolate fatigue dynamics, and streamline decision pipelines securely.
            </p>
          </div>

          {/* Four Modern Feature Cards with premium glass style */}
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            <div className="bg-white/[0.03] hover:bg-white/[0.08] border border-white/[0.06] rounded-2xl p-4 transition-all duration-300 hover:scale-[1.02] cursor-pointer group flex items-start gap-3">
              <div className="p-2 bg-[#4F46E5]/10 group-hover:bg-[#4F46E5]/20 text-indigo-400 rounded-xl border border-[#4F46E5]/15 shrink-0 transition-colors">
                <BrainCircuit className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-100">AI Sentiment Analysis</h4>
                <p className="text-[10px] text-slate-400 mt-1">Classifies employee feedback into structural positivity indexes.</p>
              </div>
            </div>

            <div className="bg-white/[0.03] hover:bg-white/[0.08] border border-white/[0.06] rounded-2xl p-4 transition-all duration-300 hover:scale-[1.02] cursor-pointer group flex items-start gap-3">
              <div className="p-2 bg-rose-500/10 group-hover:bg-rose-500/20 text-rose-400 rounded-xl border border-rose-500/15 shrink-0 transition-colors">
                <Flame className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-100">Burnout Detection</h4>
                <p className="text-[10px] text-slate-400 mt-1">Identifies emotional exhaustion indicators in unstructured reports.</p>
              </div>
            </div>

            <div className="bg-white/[0.03] hover:bg-white/[0.08] border border-white/[0.06] rounded-2xl p-4 transition-all duration-300 hover:scale-[1.02] cursor-pointer group flex items-start gap-3">
              <div className="p-2 bg-cyan-500/10 group-hover:bg-cyan-500/20 text-cyan-400 rounded-xl border border-cyan-500/15 shrink-0 transition-colors">
                <BarChart3 className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-100">Smart HR Analytics</h4>
                <p className="text-[10px] text-slate-400 mt-1">Interactive diagnostics maps across organizational boundaries.</p>
              </div>
            </div>

            <div className="bg-white/[0.03] hover:bg-white/[0.08] border border-white/[0.06] rounded-2xl p-4 transition-all duration-300 hover:scale-[1.02] cursor-pointer group flex items-start gap-3">
              <div className="p-2 bg-purple-500/10 group-hover:bg-purple-500/20 text-purple-400 rounded-xl border border-purple-500/15 shrink-0 transition-colors">
                <Lightbulb className="w-4 h-4" />
              </div>
              <div>
                <h4 className="font-bold text-xs text-slate-100">AI Recommendations</h4>
                <p className="text-[10px] text-slate-400 mt-1">Actionable policy summaries generated dynamically via Gemini.</p>
              </div>
            </div>

          </div>
        </div>

        {/* Bottom Statistics with hover animations */}
        <div className="relative z-10 border-t border-white/10 pt-6 grid grid-cols-2 sm:grid-cols-4 gap-4" id="visual_stats_footer">
          <div className="space-y-0.5 group hover:bg-white/5 p-2 rounded-xl transition-all">
            <div className="text-xl font-black text-white bg-gradient-to-r from-indigo-300 to-white bg-clip-text">10K+</div>
            <div className="text-[9px] font-bold text-indigo-300 uppercase tracking-wider">Employees</div>
          </div>
          <div className="space-y-0.5 group hover:bg-white/5 p-2 rounded-xl transition-all">
            <div className="text-xl font-black text-white bg-gradient-to-r from-indigo-300 to-white bg-clip-text">50K+</div>
            <div className="text-[9px] font-bold text-indigo-300 uppercase tracking-wider">Processed</div>
          </div>
          <div className="space-y-0.5 group hover:bg-white/5 p-2 rounded-xl transition-all">
            <div className="text-xl font-black text-white bg-gradient-to-r from-indigo-300 to-white bg-clip-text">96%</div>
            <div className="text-[9px] font-bold text-indigo-300 uppercase tracking-wider">AI Accuracy</div>
          </div>
          <div className="space-y-0.5 group hover:bg-white/5 p-2 rounded-xl transition-all">
            <div className="text-xl font-black text-emerald-400 flex items-center gap-1">
              <Fingerprint className="w-4 h-4 text-emerald-400" />
              100%
            </div>
            <div className="text-[9px] font-bold text-indigo-300 uppercase tracking-wider">Secure</div>
          </div>
        </div>

      </div>

      {/* ============================================================== */}
      {/* RIGHT COLUMN: Glassmorphic interactive cards with 55% width */}
      {/* ============================================================== */}
      <div className="flex-1 flex flex-col justify-center items-center p-6 lg:p-16 relative" id="auth_interactive_column">
        
        {/* Soft background glow meshes */}
        <div className="absolute inset-0 pointer-events-none opacity-40 overflow-hidden">
          <div className="absolute top-[10%] right-[10%] w-96 h-96 bg-purple-100 rounded-full blur-[100px]"></div>
          <div className="absolute bottom-[10%] left-[10%] w-96 h-96 bg-indigo-100 rounded-full blur-[100px]"></div>
        </div>

        {/* Glassmorphic Login container card */}
        <div className="w-full max-w-md bg-white border border-slate-200/80 rounded-[24px] shadow-2xl p-8 backdrop-blur-md relative z-10 transition-all duration-500" id="glass_auth_card">
          
          {/* Form Header */}
          <div className="text-center mb-6">
            <div className="lg:hidden flex justify-center items-center gap-2 mb-4">
              <div className="p-2 bg-indigo-600 rounded-xl text-white">
                <Shield className="w-5 h-5" />
              </div>
              <span className="text-lg font-black text-slate-800">FeedForward</span>
            </div>
            
            <h2 className="text-2xl font-black text-slate-800 tracking-tight">
              {isForgot ? 'Password Recovery' : isRegister ? 'Join FeedForward' : 'Welcome Back'}
            </h2>
            <p className="text-xs text-slate-500 mt-1 font-medium">
              {isForgot 
                ? 'Enter your details to safely reset your password credentials' 
                : isRegister 
                  ? 'Complete security enrollment steps' 
                  : 'Log in to access your continuous feedback workspaces'}
            </p>
          </div>

          {/* Toggle buttons for HR/Admin vs Employee */}
          {!isRegister && !isForgot && (
            <div className="grid grid-cols-2 gap-1.5 p-1 bg-slate-100/80 rounded-xl mb-6 border border-slate-200/50" id="role_toggles">
              <button
                type="button"
                onClick={() => setActiveRole('admin')}
                className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  activeRole === 'admin' 
                    ? 'bg-white text-indigo-700 shadow-sm border border-slate-200/30' 
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <Lock className="w-3.5 h-3.5" />
                HR / Admin Portal
              </button>
              <button
                type="button"
                onClick={() => setActiveRole('employee')}
                className={`py-2 rounded-lg text-xs font-bold transition-all cursor-pointer flex items-center justify-center gap-2 ${
                  activeRole === 'employee' 
                    ? 'bg-white text-indigo-700 shadow-sm border border-slate-200/30' 
                    : 'text-slate-500 hover:text-slate-800'
                }`}
              >
                <User className="w-3.5 h-3.5" />
                Employee Hub
              </button>
            </div>
          )}

          {/* Demo credential helpful tag */}
          {!isRegister && !isForgot && (
            <div className="mb-5 p-3 bg-indigo-50/50 border border-indigo-100/80 rounded-xl text-[10px] text-indigo-900 leading-normal">
              <span className="font-bold flex items-center gap-1 text-indigo-800">
                <Sparkles className="w-3 h-3 text-indigo-600 animate-bounce" />
                Autofill Credentials Loaded
              </span>
              <div className="mt-1 font-mono text-slate-500 flex justify-between">
                <span>User: <strong className="text-indigo-700">{email}</strong></span>
                <span>Pass: <strong className="text-indigo-700">••••••••</strong></span>
              </div>
            </div>
          )}

          {/* Feedback Messages */}
          {error && (
            <div className="mb-4 p-3 bg-rose-50 border border-rose-100 text-rose-800 text-xs rounded-xl flex items-start gap-2 animate-shake" id="error_container">
              <AlertCircle className="w-4 h-4 text-rose-600 shrink-0 mt-0.5" />
              <span className="font-medium">{error}</span>
            </div>
          )}
          {success && (
            <div className="mb-4 p-3 bg-emerald-50 border border-emerald-100 text-emerald-800 text-xs rounded-xl flex items-start gap-2" id="success_container">
              <CheckCircle2 className="w-4 h-4 text-emerald-600 shrink-0 mt-0.5" />
              <span className="font-medium">{success}</span>
            </div>
          )}

          {/* Interactive Form fields */}
          <form className="space-y-4" onSubmit={isForgot ? handleForgotPassword : isRegister ? handleRegister : handleLogin} id="auth_main_form">
            
            {/* FULL NAME (Only in register) */}
            {isRegister && (
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">Full Name</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <User className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    required
                    placeholder="e.g. Sarah Connor"
                    value={name}
                    onChange={(e) => setName(e.target.value)}
                    className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50/70 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:bg-white transition-all text-slate-800 font-semibold"
                  />
                </div>
              </div>
            )}

            {/* EMAIL */}
            <div>
              <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">Corporate Email</label>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                  <Mail className="w-4 h-4" />
                </span>
                <input
                  type="email"
                  required
                  placeholder="e.g. manager@company.com"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50/70 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:bg-white transition-all text-slate-800 font-semibold"
                />
              </div>
            </div>

            {/* DEPARTMENT DROPDOWN (Only in register) */}
            {isRegister && (
              <div>
                <label className="block text-[11px] font-bold text-slate-700 uppercase tracking-wider mb-1.5">Organizational Department</label>
                <div className="relative">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                    <Building className="w-4 h-4" />
                  </span>
                  <select
                    value={departmentId}
                    onChange={(e) => setDepartmentId(e.target.value)}
                    className="w-full pl-10 pr-8 py-2.5 text-xs bg-slate-50/70 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:bg-white transition-all text-slate-800 font-semibold appearance-none"
                  >
                    {departments.map((dept) => (
                      <option key={dept.id} value={dept.id}>
                        {dept.name}
                      </option>
                    ))}
                  </select>
                </div>
              </div>
            )}

            {/* PASSWORD */}
            <div>
              <div className="flex justify-between items-center mb-1.5">
                <label className="text-[11px] font-bold text-slate-700 uppercase tracking-wider">
                  {isForgot ? 'New Password' : 'Security Password'}
                </label>
                {!isRegister && !isForgot && (
                  <button
                    type="button"
                    onClick={() => { setIsForgot(true); setError(''); setSuccess(''); }}
                    className="text-[11px] text-[#4F46E5] hover:text-[#7C3AED] hover:underline font-bold"
                  >
                    Forgot password?
                  </button>
                )}
              </div>
              <div className="relative">
                <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                  <Lock className="w-4 h-4" />
                </span>
                <input
                  type={showPassword ? "text" : "password"}
                  required
                  placeholder="••••••••"
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  className="w-full pl-10 pr-10 py-2.5 text-xs bg-slate-50/70 border border-slate-200 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-indigo-500 focus:bg-white transition-all text-slate-800 font-semibold"
                />
                <button
                  type="button"
                  onClick={() => setShowPassword(!showPassword)}
                  className="absolute inset-y-0 right-0 flex items-center pr-3 text-slate-400 hover:text-indigo-600 cursor-pointer"
                >
                  {showPassword ? <EyeOff className="w-4 h-4" /> : <Eye className="w-4 h-4" />}
                </button>
              </div>
            </div>

            {/* Remember Me checkbox (Only in Login) */}
            {!isRegister && !isForgot && (
              <div className="flex items-center justify-between pt-1">
                <label className="flex items-center gap-2 cursor-pointer">
                  <input
                    type="checkbox"
                    checked={rememberMe}
                    onChange={(e) => setRememberMe(e.target.checked)}
                    className="w-4 h-4 text-indigo-600 border-slate-300 rounded focus:ring-indigo-500 cursor-pointer"
                  />
                  <span className="text-[11px] font-semibold text-slate-600">Remember me</span>
                </label>
                <button
                  type="button"
                  onClick={() => setSuccess("Academic System Help: Access corporate directories with default secure emails.")}
                  className="text-[10px] text-slate-400 hover:text-slate-600 flex items-center gap-1 font-medium"
                >
                  <HelpCircle className="w-3.5 h-3.5" />
                  Need Help?
                </button>
              </div>
            )}

            {/* Submit Button with Gradient */}
            <button
              type="submit"
              disabled={loading}
              className="w-full mt-4 py-3 bg-gradient-to-r from-indigo-600 via-indigo-700 to-[#7C3AED] hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-indigo-200/50 flex items-center justify-center gap-2 transition-all duration-300 hover:scale-[1.01] active:scale-95 disabled:opacity-50 cursor-pointer"
            >
              {loading ? (
                <div className="w-4 h-4 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
              ) : (
                <>
                  <span>
                    {isForgot 
                      ? 'Confirm Credentials Reset' 
                      : isRegister 
                        ? 'Complete Security Registration' 
                        : 'Secure Log In'}
                  </span>
                  <ArrowRight className="w-4 h-4" />
                </>
              )}
            </button>
          </form>

          {/* Third-Party Continue with Google button */}
          {!isRegister && !isForgot && (
            <div className="mt-5 space-y-4">
              <div className="relative flex items-center justify-center">
                <div className="absolute inset-0 flex items-center">
                  <div className="w-full border-t border-slate-200"></div>
                </div>
                <span className="relative px-3 bg-white text-[10px] text-slate-400 uppercase font-black tracking-widest">or continue with</span>
              </div>

              <button
                type="button"
                onClick={handleGoogleLogin}
                className="w-full py-2.5 bg-white border border-slate-200 hover:bg-slate-50 text-slate-700 text-xs font-bold rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm"
              >
                <svg className="w-4 h-4" viewBox="0 0 24 24">
                  <path fill="#EA4335" d="M12 5.04c1.62 0 3.08.56 4.22 1.65l3.17-3.17C17.47 1.6 14.93 1 12 1 7.31 1 3.28 3.69 1.25 7.64l3.82 2.96C6.01 7.37 8.78 5.04 12 5.04z" />
                  <path fill="#4285F4" d="M23.49 12.27c0-.81-.07-1.59-.2-2.36H12v4.47h6.44c-.28 1.47-1.11 2.71-2.36 3.55l3.66 2.84c2.14-1.97 3.39-4.88 3.39-8.5z" />
                  <path fill="#FBBC05" d="M5.07 10.6c-.23-.68-.36-1.42-.36-2.18s.13-1.5.36-2.18L1.25 3.28C.45 4.88 0 6.69 0 8.6s.45 3.72 1.25 5.32l3.82-2.96z" />
                  <path fill="#34A853" d="M12 23c3.24 0 5.97-1.07 7.96-2.92l-3.66-2.84c-1.01.68-2.31 1.09-3.9 1.09-3.22 0-5.99-2.33-6.96-5.46L1.62 15.8C3.65 19.81 7.68 23 12 23z" />
                </svg>
                <span>Google Enterprise SSO</span>
              </button>
            </div>
          )}

          {/* Bottom redirection controls */}
          <div className="mt-6 pt-5 border-t border-slate-100 text-center text-xs text-slate-500">
            {isForgot ? (
              <button
                onClick={() => { setIsForgot(false); setError(''); setSuccess(''); }}
                className="text-indigo-600 hover:text-purple-600 hover:underline font-bold flex items-center gap-1.5 mx-auto transition-colors"
              >
                <CornerDownLeft className="w-3.5 h-3.5" />
                Return to login portal
              </button>
            ) : isRegister ? (
              <p className="font-semibold text-slate-500">
                Already have a FeedForward account?{' '}
                <button
                  onClick={() => { setIsRegister(false); setError(''); setSuccess(''); }}
                  className="text-indigo-600 hover:text-purple-600 hover:underline font-bold transition-colors ml-1"
                >
                  Log in safely
                </button>
              </p>
            ) : (
              <div className="space-y-3">
                <p className="font-semibold text-slate-500">
                  New corporate employee?{' '}
                  <button
                    onClick={() => { setIsRegister(true); setError(''); setSuccess(''); }}
                    className="text-indigo-600 hover:text-purple-600 hover:underline font-bold transition-colors ml-1"
                  >
                    Register account
                  </button>
                </p>
                <div>
                  <button
                    onClick={() => setSuccess("Need assistance? Please contact IT Admin at support@company.com")}
                    className="text-[10px] text-slate-400 hover:text-indigo-600 font-bold transition-colors"
                  >
                    Need Help / Contact support
                  </button>
                </div>
              </div>
            )}
          </div>

        </div>

      </div>

    </div>
  );
}
