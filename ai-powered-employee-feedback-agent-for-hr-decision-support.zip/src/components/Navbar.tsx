import React, { useState, useEffect } from 'react';
import { 
  Bell, 
  LogOut, 
  User, 
  Sparkles, 
  Shield, 
  Mail, 
  Check, 
  AlertTriangle,
  Search,
  Sun,
  Moon,
  HelpCircle,
  Menu,
  ChevronDown
} from 'lucide-react';
import { Employee, Notification } from '../types';

interface NavbarProps {
  user: Employee;
  token: string;
  onLogout: () => void;
  triggerRefresh?: boolean;
}

export default function Navbar({ user, token, onLogout, triggerRefresh }: NavbarProps) {
  const [notifications, setNotifications] = useState<Notification[]>([]);
  const [isOpen, setIsOpen] = useState(false);
  const [isProfileOpen, setIsProfileOpen] = useState(false);
  const [darkMode, setDarkMode] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');

  // Sync dark mode preference with localStorage & DOM
  useEffect(() => {
    const isDark = localStorage.getItem('darkMode') === 'true';
    setDarkMode(isDark);
    if (isDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, []);

  const toggleDarkMode = () => {
    const nextDark = !darkMode;
    setDarkMode(nextDark);
    localStorage.setItem('darkMode', String(nextDark));
    if (nextDark) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  };

  const fetchNotifications = () => {
    fetch('/api/notifications', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setNotifications(data);
        }
      })
      .catch(err => console.error('Error fetching notifications:', err));
  };

  useEffect(() => {
    fetchNotifications();
    const interval = setInterval(fetchNotifications, 30000);
    return () => clearInterval(interval);
  }, [token, triggerRefresh]);

  const handleMarkAsRead = async (id: string) => {
    try {
      const response = await fetch(`/api/notifications/${id}/read`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        setNotifications(prev => prev.map(n => n.id === id ? { ...n, read: true } : n));
      }
    } catch (err) {
      console.error('Error marking notification as read:', err);
    }
  };

  const unreadCount = notifications.filter(n => !n.read).length;

  // Get User Initials for Profile Avatar
  const getUserInitials = (name: string) => {
    if (!name) return 'U';
    const parts = name.split(' ');
    if (parts.length >= 2) {
      return `${parts[0][0]}${parts[1][0]}`.toUpperCase();
    }
    return name[0].toUpperCase();
  };

  return (
    <header className="bg-white dark:bg-[#0F172A] border-b border-slate-100 dark:border-slate-800 h-16 flex items-center justify-between px-6 sticky top-0 z-40 transition-colors duration-300 shadow-sm" id="premium_navbar">
      
      {/* Left side: Enterprise Brand Logo */}
      <div className="flex items-center gap-3">
        <div className="p-2 bg-gradient-to-br from-indigo-600 to-purple-600 rounded-xl text-white shadow-md shadow-indigo-100 dark:shadow-none animate-pulse">
          <Shield className="w-5 h-5" />
        </div>
        <div className="text-left">
          <span className="font-black text-lg text-slate-800 dark:text-slate-100 tracking-tight block">FeedForward</span>
          <div className="text-[9px] uppercase tracking-widest text-indigo-500 dark:text-indigo-400 font-extrabold -mt-1 font-mono">
            Enterprise SaaS Portal
          </div>
        </div>
        <span className="hidden sm:inline-block px-2.5 py-0.5 text-[9px] bg-indigo-50 dark:bg-indigo-950/40 text-[#4F46E5] dark:text-indigo-300 font-black rounded-full border border-indigo-100/50 dark:border-indigo-900/30 uppercase tracking-wider font-mono">
          Gemini Agent v1.5
        </span>
      </div>

      {/* Middle section: Search Bar and Quick tools */}
      <div className="flex-1 max-w-sm mx-8 hidden md:block">
        <div className="relative">
          <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400 dark:text-slate-500">
            <Search className="w-4 h-4" />
          </span>
          <input
            type="text"
            placeholder="Search diagnostics, employees, logs..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full pl-10 pr-4 py-2 text-xs bg-slate-50 dark:bg-slate-800/60 border border-slate-200 dark:border-slate-700/80 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:focus:ring-indigo-400 focus:bg-white dark:focus:bg-[#0F172A] text-slate-700 dark:text-slate-200 font-semibold placeholder:text-slate-400 dark:placeholder:text-slate-500 transition-all duration-200"
          />
        </div>
      </div>

      {/* Right side: Tools, Dark Mode, Notifications, User Avatar */}
      <div className="flex items-center gap-3.5">
        
        {/* Dark Mode Toggle */}
        <button
          onClick={toggleDarkMode}
          className="p-2 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-all cursor-pointer relative"
          title={darkMode ? "Switch to Light Mode" : "Switch to Dark Mode"}
        >
          {darkMode ? <Sun className="w-4 h-4 text-amber-400" /> : <Moon className="w-4 h-4" />}
        </button>

        {/* Live Academic Dossier Shortcut */}
        <button
          onClick={() => {
            const btn = document.getElementById('academic_dossier_btn');
            if (btn) btn.click();
          }}
          className="hidden sm:flex items-center gap-1.5 px-3 py-1.5 text-[10px] font-bold text-slate-600 dark:text-slate-300 bg-slate-50 dark:bg-slate-800/80 border border-slate-200/60 dark:border-slate-700 rounded-xl hover:bg-slate-100 dark:hover:bg-slate-700 transition-all cursor-pointer"
          title="Project Viva presentation handbook"
        >
          <Sparkles className="w-3.5 h-3.5 text-indigo-500" />
          <span>Documentation Dossier</span>
        </button>

        {/* Notifications dropdown trigger */}
        <div className="relative">
          <button 
            onClick={() => { setIsOpen(!isOpen); setIsProfileOpen(false); }}
            className="p-2 text-slate-500 dark:text-slate-400 hover:text-slate-800 dark:hover:text-slate-100 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-xl transition-all relative cursor-pointer"
            title="System Inbox"
          >
            <Bell className="w-4.5 h-4.5" />
            {unreadCount > 0 && (
              <span className="absolute top-1 right-1 w-4 h-4 bg-gradient-to-r from-rose-500 to-red-600 text-white rounded-full text-[9px] font-black flex items-center justify-center border-2 border-white dark:border-[#0F172A] animate-bounce">
                {unreadCount}
              </span>
            )}
          </button>

          {/* Notifications List Card (Glass style) */}
          {isOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setIsOpen(false)}></div>
              <div className="absolute right-0 mt-3 w-80 bg-white dark:bg-[#1E293B] border border-slate-200/70 dark:border-slate-700 rounded-2xl shadow-2xl z-50 overflow-hidden animate-slide-down">
                <div className="p-4 border-b border-slate-100 dark:border-slate-700 bg-slate-50/70 dark:bg-slate-850 flex items-center justify-between">
                  <span className="font-extrabold text-xs text-slate-800 dark:text-slate-200 tracking-tight">System Security Inbox</span>
                  {unreadCount > 0 && (
                    <span className="text-[9px] font-bold text-rose-600 dark:text-rose-400 bg-rose-50 dark:bg-rose-950/50 px-2 py-0.5 rounded-full uppercase tracking-wider">
                      {unreadCount} active
                    </span>
                  )}
                </div>

                <div className="max-h-72 overflow-y-auto divide-y divide-slate-100 dark:divide-slate-700">
                  {notifications.length === 0 ? (
                    <div className="p-8 text-center text-xs text-slate-400 dark:text-slate-500 flex flex-col items-center gap-1">
                      <Mail className="w-6 h-6 text-slate-300 dark:text-slate-600" />
                      <span className="font-semibold">Your inbox is clear</span>
                    </div>
                  ) : (
                    notifications.map((notif) => (
                      <div 
                        key={notif.id} 
                        className={`p-4 transition-all text-left flex gap-3 ${
                          notif.read ? 'bg-white dark:bg-[#1E293B] opacity-75' : 'bg-indigo-50/20 dark:bg-indigo-950/10'
                        }`}
                      >
                        <div className="mt-0.5 shrink-0">
                          {notif.title.includes('Alert') || notif.title.includes('Burnout') ? (
                            <div className="p-1.5 bg-rose-50 dark:bg-rose-950/50 text-rose-600 dark:text-rose-400 rounded-lg border border-rose-100 dark:border-rose-900/30">
                              <AlertTriangle className="w-3.5 h-3.5" />
                            </div>
                          ) : (
                            <div className="p-1.5 bg-indigo-50 dark:bg-indigo-950/50 text-[#4F46E5] dark:text-indigo-400 rounded-lg border border-indigo-100 dark:border-indigo-900/30">
                              <Sparkles className="w-3.5 h-3.5" />
                            </div>
                          )}
                        </div>
                        <div className="flex-1 space-y-1">
                          <div className="flex items-start justify-between gap-2">
                            <span className="font-extrabold text-xs text-slate-800 dark:text-slate-200 leading-tight">
                              {notif.title}
                            </span>
                            {!notif.read && (
                              <button 
                                onClick={() => handleMarkAsRead(notif.id)}
                                className="p-1 hover:bg-slate-100 dark:hover:bg-slate-700 text-slate-400 hover:text-[#4F46E5] dark:hover:text-indigo-400 rounded transition-all cursor-pointer"
                                title="Mark read"
                              >
                                <Check className="w-3 h-3" />
                              </button>
                            )}
                          </div>
                          <p className="text-[10px] text-slate-500 dark:text-slate-400 leading-normal font-medium">
                            {notif.message}
                          </p>
                          <div className="text-[9px] text-slate-400 dark:text-slate-500 font-mono">
                            {new Date(notif.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </div>
                        </div>
                      </div>
                    ))
                  )}
                </div>
              </div>
            </>
          )}
        </div>

        {/* Separator */}
        <div className="h-6 w-px bg-slate-200 dark:bg-slate-700"></div>

        {/* User Profile Avatar with dropdown */}
        <div className="relative">
          <button
            onClick={() => { setIsProfileOpen(!isProfileOpen); setIsOpen(false); }}
            className="flex items-center gap-2 cursor-pointer focus:outline-none group"
            id="user_profile_trigger"
          >
            <div className="w-9 h-9 rounded-xl bg-gradient-to-br from-indigo-500 via-indigo-600 to-purple-600 text-white font-extrabold text-xs flex items-center justify-center shadow-md shadow-indigo-100 dark:shadow-none border border-indigo-400/20 group-hover:scale-105 transition-all">
              {getUserInitials(user.name)}
            </div>
            <div className="hidden lg:flex flex-col text-left">
              <span className="text-xs font-black text-slate-800 dark:text-slate-200 block max-w-[100px] truncate leading-none">
                {user.name}
              </span>
              <span className="text-[9px] font-bold text-slate-400 uppercase tracking-widest mt-0.5 leading-none">
                {user.role === 'hr' ? 'HR Director' : 'Staff Employee'}
              </span>
            </div>
            <ChevronDown className="w-3.5 h-3.5 text-slate-400 group-hover:text-slate-600 transition-colors" />
          </button>

          {/* Profile Dropdown Menu */}
          {isProfileOpen && (
            <>
              <div className="fixed inset-0 z-40" onClick={() => setIsProfileOpen(false)}></div>
              <div className="absolute right-0 mt-3 w-56 bg-white dark:bg-[#1E293B] border border-slate-200/70 dark:border-slate-700 rounded-2xl shadow-2xl z-50 overflow-hidden animate-slide-down">
                <div className="p-4 bg-slate-50 dark:bg-slate-850/50 border-b border-slate-100 dark:border-slate-700">
                  <span className="text-xs font-black text-slate-800 dark:text-slate-200 block truncate">{user.name}</span>
                  <span className="text-[10px] text-slate-400 font-mono block truncate mt-0.5">{user.email}</span>
                </div>
                
                <div className="p-1.5 space-y-0.5">
                  <div className="px-3 py-2 text-[10px] font-bold text-slate-400 uppercase tracking-widest">
                    Operational Scope
                  </div>
                  <div className="px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 flex justify-between">
                    <span>Authorization:</span>
                    <span className="uppercase text-indigo-600 dark:text-indigo-400 font-black">{user.role}</span>
                  </div>
                  <div className="px-3 py-1.5 text-xs font-semibold text-slate-600 dark:text-slate-300 flex justify-between">
                    <span>Department:</span>
                    <span className="text-slate-800 dark:text-slate-200 font-black">Active</span>
                  </div>

                  <div className="border-t border-slate-100 dark:border-slate-700 my-1.5"></div>

                  <button
                    onClick={onLogout}
                    className="w-full px-3 py-2 rounded-xl text-left text-xs font-bold text-rose-600 hover:bg-rose-50 dark:hover:bg-rose-950/20 flex items-center gap-2.5 transition-colors cursor-pointer"
                  >
                    <LogOut className="w-4 h-4 text-rose-500" />
                    <span>Secure Logout</span>
                  </button>
                </div>
              </div>
            </>
          )}
        </div>

      </div>

    </header>
  );
}
