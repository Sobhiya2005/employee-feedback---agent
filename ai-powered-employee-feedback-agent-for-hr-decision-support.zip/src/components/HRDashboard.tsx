import React, { useState, useEffect } from 'react';
import { 
  Users, 
  FileText, 
  AlertTriangle, 
  HelpCircle, 
  Activity, 
  BarChart2, 
  PieChart as PieIcon, 
  LineChart as LineIcon, 
  ArrowDownToLine, 
  Search, 
  Filter, 
  Plus, 
  ShieldAlert,
  Sliders, 
  MessageSquare, 
  ChevronRight, 
  CheckCircle2, 
  Clock, 
  Trash, 
  Eye, 
  RefreshCw, 
  Send, 
  BookOpen, 
  ShieldCheck, 
  Mail,
  ChevronLeft,
  Building,
  AlertCircle
} from 'lucide-react';
import { 
  BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend, ResponsiveContainer,
  LineChart, Line, AreaChart, Area,
  PieChart, Pie, Cell
} from 'recharts';
import { Employee, Department, Feedback, HRDashboardStats, ActivityLog } from '../types';
import StatsCard from './StatsCard';

interface HRDashboardProps {
  token: string;
  onRefreshNotifications: () => void;
}

export default function HRDashboard({ token, onRefreshNotifications }: HRDashboardProps) {
  const [stats, setStats] = useState<HRDashboardStats | null>(null);
  const [feedbacks, setFeedbacks] = useState<Feedback[]>([]);
  const [employees, setEmployees] = useState<Employee[]>([]);
  const [departments, setDepartments] = useState<Department[]>([]);
  const [activityLogs, setActivityLogs] = useState<ActivityLog[]>([]);
  
  // Navigation tabs
  const [hrTab, setHrTab] = useState<'analytics' | 'feedback' | 'employees' | 'departments' | 'logs'>('analytics');

  // Sidebar collapsible state
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  // Filters for feedback list
  const [filterSentiment, setFilterSentiment] = useState('');
  const [filterBurnout, setFilterBurnout] = useState('');
  const [filterDepartmentId, setFilterDepartmentId] = useState('');
  const [searchFeedback, setSearchFeedback] = useState('');

  // Filters for employee directory
  const [searchEmployee, setSearchEmployee] = useState('');

  // Form state for creating department
  const [newDeptName, setNewDeptName] = useState('');
  const [newDeptManager, setNewDeptManager] = useState('');
  const [deptFormSuccess, setDeptFormSuccess] = useState('');

  // Expanded feedback details in list view
  const [expandedFbId, setExpandedFbId] = useState<string | null>(null);

  // loading state
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    fetchStats();
    fetchFeedbacks();
    fetchEmployees();
    fetchDepartments();
    fetchActivityLogs();
  }, [hrTab]);

  const fetchStats = () => {
    fetch('/api/hr/stats', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => setStats(data))
      .catch(err => console.error('Error fetching stats:', err));
  };

  const fetchFeedbacks = () => {
    const params = new URLSearchParams();
    if (filterSentiment) params.append('sentiment', filterSentiment);
    if (filterBurnout) params.append('burnoutRisk', filterBurnout);
    if (filterDepartmentId) params.append('departmentId', filterDepartmentId);
    if (searchFeedback) params.append('search', searchFeedback);

    fetch(`/api/feedbacks/all?${params.toString()}`, {
      headers: { 'Authorization': `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setFeedbacks(data);
        }
      })
      .catch(err => console.error('Error fetching feedbacks:', err));
  };

  const fetchEmployees = () => {
    fetch('/api/employees', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setEmployees(data);
        }
      })
      .catch(err => console.error('Error fetching employees:', err));
  };

  const fetchDepartments = () => {
    fetch('/api/departments')
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setDepartments(data);
        }
      })
      .catch(err => console.error('Error fetching departments:', err));
  };

  const fetchActivityLogs = () => {
    fetch('/api/logs', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setActivityLogs(data);
        }
      })
      .catch(err => console.error('Error fetching logs:', err));
  };

  const handleToggleEmployee = async (id: string) => {
    try {
      const response = await fetch(`/api/employees/${id}/toggle`, {
        method: 'POST',
        headers: { 'Authorization': `Bearer ${token}` }
      });
      if (response.ok) {
        fetchEmployees();
        fetchStats();
      }
    } catch (err) {
      console.error('Error toggling employee status:', err);
    }
  };

  const handleCreateDepartment = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newDeptName || !newDeptManager) return;

    try {
      const response = await fetch('/api/departments', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ name: newDeptName, managerName: newDeptManager })
      });
      if (response.ok) {
        setDeptFormSuccess('Department created successfully!');
        setNewDeptName('');
        setNewDeptManager('');
        fetchDepartments();
        setTimeout(() => setDeptFormSuccess(''), 3000);
      }
    } catch (err) {
      console.error('Error creating department:', err);
    }
  };

  const handleExportCSV = () => {
    window.open(`/api/reports/export/csv?authorization=Bearer ${token}`, '_blank');
  };

  // Pre-configured colors for chart pieces
  const SENTIMENT_COLORS = {
    positive: '#10b981', // emerald-500
    neutral: '#f59e0b',  // amber-500
    negative: '#f43f5e'  // rose-500
  };

  const BURNOUT_COLORS = {
    low: '#10b981',
    medium: '#f59e0b',
    high: '#f43f5e'
  };

  const handleApplyFeedbackFilters = (e: React.FormEvent) => {
    e.preventDefault();
    fetchFeedbacks();
  };

  const getSentimentPillStyle = (sentiment?: string) => {
    switch (sentiment) {
      case 'positive': return 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border-emerald-100/40';
      case 'negative': return 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 border-rose-100/40';
      default: return 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 border-amber-100/40';
    }
  };

  const getBurnoutPillStyle = (risk?: string) => {
    switch (risk) {
      case 'high': return 'bg-rose-100 dark:bg-rose-950 text-rose-950 dark:text-rose-300 font-extrabold border-rose-200/50';
      case 'medium': return 'bg-amber-100 dark:bg-amber-950/50 text-amber-950 dark:text-amber-300 font-bold border-amber-200/50';
      default: return 'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-950 dark:text-emerald-300 font-semibold border-emerald-200/50';
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#0F172A] text-slate-800 dark:text-slate-100 font-sans transition-colors duration-300" id="hr_dashboard_root">
      
      {/* Outer Flex Container for Sidebar + Workspace Frame */}
      <div className="flex flex-col lg:flex-row max-w-7xl mx-auto px-4 sm:px-6 py-6 gap-6" id="hr_dashboard_layout">
        
        {/* ============================================================== */}
        {/* COLLAPSIBLE SIDEBAR: Visible on desktop, sticky position */}
        {/* ============================================================== */}
        <aside 
          className={`hidden lg:flex flex-col bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 rounded-[24px] p-5 shrink-0 text-slate-500 dark:text-slate-400 shadow-xl space-y-6 self-start sticky top-20 transition-all duration-300 ${
            isSidebarCollapsed ? 'w-20' : 'w-64'
          }`} 
          id="hr_collapsible_sidebar"
        >
          {/* Sidebar Top Header with Collapse Toggle */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            {!isSidebarCollapsed && (
              <div className="space-y-0.5 text-left animate-fade-in">
                <span className="text-[9px] uppercase font-black tracking-widest text-[#4F46E5] dark:text-indigo-400">Decision Support</span>
                <h3 className="font-extrabold text-slate-800 dark:text-slate-100 text-sm tracking-tight">HR Control Center</h3>
              </div>
            )}
            
            <button
              onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
              className="p-1.5 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-[#4F46E5] transition-all ml-auto cursor-pointer border border-slate-100 dark:border-slate-800"
              title={isSidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
            >
              {isSidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="flex flex-col gap-1.5">
            {[
              { id: 'analytics', label: 'Morale Diagnostics', icon: <BarChart2 className="w-4.5 h-4.5" /> },
              { id: 'feedback', label: 'All Feedbacks', icon: <MessageSquare className="w-4.5 h-4.5" /> },
              { id: 'employees', label: 'Employee Directory', icon: <Users className="w-4.5 h-4.5" /> },
              { id: 'departments', label: 'Departments', icon: <Sliders className="w-4.5 h-4.5" /> },
              { id: 'logs', label: 'System Logs', icon: <Activity className="w-4.5 h-4.5" /> }
            ].map((tab) => {
              const active = hrTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setHrTab(tab.id as any)}
                  className={`w-full py-3 rounded-xl text-xs font-bold flex items-center transition-all cursor-pointer border-l-2 text-left ${
                    isSidebarCollapsed ? 'justify-center px-0' : 'px-4'
                  } ${
                    active 
                      ? 'bg-indigo-500/5 text-indigo-600 dark:text-indigo-400 border-indigo-500 bg-slate-850' 
                      : 'border-transparent text-slate-500 hover:text-slate-800 dark:hover:text-slate-200 hover:bg-slate-50/50 dark:hover:bg-slate-800/40'
                  }`}
                  title={isSidebarCollapsed ? tab.label : ''}
                >
                  <span className={`${active ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 dark:text-slate-500'} shrink-0`}>
                    {tab.icon}
                  </span>
                  {!isSidebarCollapsed && <span className="ml-3 animate-fade-in">{tab.label}</span>}
                </button>
              );
            })}
          </nav>

          {/* Sidebar Status Footer */}
          {!isSidebarCollapsed && (
            <div className="pt-6 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400 dark:text-slate-500 space-y-2.5 text-left animate-fade-in">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="font-semibold text-slate-600 dark:text-slate-400">Gemini Core Online</span>
              </div>
              <div className="font-mono text-[9px] text-slate-400">Ver: 1.5.0 • SSL Secured</div>
            </div>
          )}
        </aside>

        {/* ============================================================== */}
        {/* WORKSPACE AREA: Main screen frame containing selected view */}
        {/* ============================================================== */}
        <div className="flex-1 min-w-0 space-y-6">
          
          {/* Header row with Title and Top Mobile Nav tabs */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 pb-5 border-b border-slate-100 dark:border-slate-800 text-left">
            <div>
              <h1 className="text-2xl font-black text-slate-800 dark:text-slate-100 tracking-tight flex items-center gap-2">
                HR Decision Support Portal
                <span className="text-[10px] bg-indigo-50 dark:bg-indigo-950 text-indigo-700 dark:text-indigo-300 font-bold px-2 py-0.5 rounded-md border border-indigo-100 dark:border-indigo-900/30">
                  AI Diagnostics
                </span>
              </h1>
              <p className="text-xs text-slate-400 dark:text-slate-400 mt-1 font-semibold">
                Real-time organizational insights powered by Google Gemini. Continuously monitor morale, fatigue, and satisfaction indexes.
              </p>
            </div>

            {/* Mobile / Tablet Top Navigation - Hidden on desktop */}
            <div className="lg:hidden flex flex-wrap gap-1 bg-slate-100 dark:bg-slate-800/80 p-1 rounded-2xl border border-slate-200/50 dark:border-slate-700 shrink-0">
              {[
                { id: 'analytics', label: 'Morale Diagnostics', icon: <BarChart2 className="w-3.5 h-3.5" /> },
                { id: 'feedback', label: 'All Feedbacks', icon: <MessageSquare className="w-3.5 h-3.5" /> },
                { id: 'employees', label: 'Employee Directory', icon: <Users className="w-3.5 h-3.5" /> },
                { id: 'departments', label: 'Departments', icon: <Sliders className="w-3.5 h-3.5" /> },
                { id: 'logs', label: 'System Logs', icon: <Activity className="w-3.5 h-3.5" /> }
              ].map((tab) => (
                <button
                  key={tab.id}
                  onClick={() => setHrTab(tab.id as any)}
                  className={`px-3.5 py-1.5 rounded-xl text-[10px] font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                    hrTab === tab.id 
                      ? 'bg-white dark:bg-[#1E293B] text-[#4F46E5] dark:text-indigo-400 shadow-sm border border-slate-200/30' 
                      : 'text-slate-600 dark:text-slate-400 hover:text-slate-800'
                  }`}
                >
                  {tab.icon}
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          {/* Stats quick overview cards */}
          {stats && (
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5" id="hr_stats_grid">
              <StatsCard 
                title="Total Staff" 
                value={stats.totalEmployees} 
                icon={<Users className="w-5 h-5 text-indigo-600 dark:text-indigo-400" />} 
                subtitle="Active corporate accounts"
              />
              <StatsCard 
                title="Feedback Index" 
                value={stats.totalFeedback} 
                icon={<FileText className="w-5 h-5 text-sky-600 dark:text-sky-400" />} 
                subtitle="Cumulative user reports"
              />
              <StatsCard 
                title="Avg Satisfaction" 
                value={`${stats.averageSatisfaction}%`} 
                icon={<BarChart2 className="w-5 h-5 text-emerald-600 dark:text-emerald-400" />} 
                subtitle="Aggregated satisfaction"
                trend={{ value: 'Norm: 75%', isPositive: stats.averageSatisfaction >= 70 }}
              />
              <StatsCard 
                title="Critical Burnout Risks" 
                value={stats.burnoutCount} 
                icon={<ShieldAlert className="w-5 h-5 text-rose-600 dark:text-rose-400 animate-pulse" />} 
                subtitle="Require intervention"
                trend={{ value: `${stats.burnoutCount > 0 ? 'Urgent Actions' : 'Normal State'}`, isPositive: stats.burnoutCount === 0 }}
              />
            </div>
          )}

          {/* ============================================================== */}
          {/* VIEW: MORALE DIAGNOSTICS & CHARTS */}
          {/* ============================================================== */}
          {hrTab === 'analytics' && stats && (
            <div className="space-y-6" id="view_diagnostics">
              
              {/* Row 1: Sentiment Split (Donut) & Monthly Trends Area Chart */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Donut Chart: Sentiment distribution */}
                <div className="lg:col-span-5 bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 p-6 rounded-[24px] shadow-sm flex flex-col justify-between">
                  <div>
                    <h3 className="font-extrabold text-slate-850 dark:text-slate-100 text-sm flex items-center gap-2 text-left">
                      <PieIcon className="w-4 h-4 text-[#4F46E5] dark:text-indigo-400" />
                      Morale Sentiment Distribution
                    </h3>
                    <p className="text-[11px] text-slate-400 dark:text-slate-400 mt-1 mb-6 text-left font-medium">
                      Reflects aggregated sentiment score analysis derived from continuous qualitative reports.
                    </p>
                  </div>

                  <div className="h-60 flex justify-center items-center relative">
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={[
                            { name: 'Positive', value: stats.positivePercentage, fill: SENTIMENT_COLORS.positive },
                            { name: 'Neutral', value: stats.neutralPercentage, fill: SENTIMENT_COLORS.neutral },
                            { name: 'Negative', value: stats.negativePercentage, fill: SENTIMENT_COLORS.negative }
                          ].filter(d => d.value > 0)}
                          cx="50%"
                          cy="50%"
                          innerRadius={55}
                          outerRadius={80}
                          paddingAngle={3}
                          dataKey="value"
                        >
                          {/* Cells are auto-filled */}
                        </Pie>
                        <Tooltip formatter={(value) => [`${value}%`, 'Percentage']} />
                        <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 'bold' }} />
                      </PieChart>
                    </ResponsiveContainer>
                    {/* Inner absolute content */}
                    <div className="absolute flex flex-col items-center">
                      <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-wider">Index rating</span>
                      <span className="text-xl font-black text-slate-800 dark:text-slate-100">{stats.averageSatisfaction}%</span>
                    </div>
                  </div>

                  <div className="grid grid-cols-3 gap-3 text-center mt-4 pt-4 border-t border-slate-100 dark:border-slate-800/80">
                    <div>
                      <span className="text-[9px] font-black text-emerald-500 uppercase tracking-widest block">Positive</span>
                      <div className="text-sm font-black text-slate-800 dark:text-slate-100 mt-0.5">{stats.positivePercentage}%</div>
                    </div>
                    <div>
                      <span className="text-[9px] font-black text-amber-500 uppercase tracking-widest block">Neutral</span>
                      <div className="text-sm font-black text-slate-800 dark:text-slate-100 mt-0.5">{stats.neutralPercentage}%</div>
                    </div>
                    <div>
                      <span className="text-[9px] font-black text-rose-500 uppercase tracking-widest block">Negative</span>
                      <div className="text-sm font-black text-slate-800 dark:text-slate-100 mt-0.5">{stats.negativePercentage}%</div>
                    </div>
                  </div>
                </div>

                {/* Monthly Volume Area Chart */}
                <div className="lg:col-span-7 bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 p-6 rounded-[24px] shadow-sm">
                  <h3 className="font-extrabold text-slate-850 dark:text-slate-100 text-sm flex items-center gap-2 text-left">
                    <LineIcon className="w-4 h-4 text-[#4F46E5] dark:text-indigo-400" />
                    Continuous Feedback Volume & Satisfaction Metrics
                  </h3>
                  <p className="text-[11px] text-slate-400 dark:text-slate-400 mt-1 mb-6 text-left font-medium">
                    Historical tracking of satisfaction scores and submission volumes.
                  </p>

                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <AreaChart data={stats.monthlyTrends}>
                        <defs>
                          <linearGradient id="colorSatisfy" x1="0" y1="0" x2="0" y2="1">
                            <stop offset="5%" stopColor="#4F46E5" stopOpacity={0.25}/>
                            <stop offset="95%" stopColor="#4F46E5" stopOpacity={0}/>
                          </linearGradient>
                        </defs>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" opacity={0.3} />
                        <XAxis dataKey="month" tick={{ fontSize: 10, fontWeight: 'semibold' }} stroke="#94A3B8" />
                        <YAxis tick={{ fontSize: 10, fontWeight: 'semibold' }} stroke="#94A3B8" />
                        <Tooltip />
                        <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 'semibold' }} />
                        <Area type="monotone" name="Satisfaction Score (%)" dataKey="avgSatisfaction" stroke="#4F46E5" strokeWidth={2.5} fillOpacity={1} fill="url(#colorSatisfy)" />
                        <Bar name="Submissions Count" dataKey="feedbackCount" fill="#93C5FD" opacity={0.8} radius={[4, 4, 0, 0]} barSize={24} />
                      </AreaChart>
                    </ResponsiveContainer>
                  </div>
                </div>

              </div>

              {/* Row 2: Department-wise comparatives and Extracted AI Bottlenecks */}
              <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
                
                {/* Department Comparative Performance */}
                <div className="lg:col-span-7 bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 p-6 rounded-[24px] shadow-sm">
                  <h3 className="font-extrabold text-slate-850 dark:text-slate-100 text-sm flex items-center gap-2 text-left">
                    <BarChart2 className="w-4 h-4 text-[#4F46E5] dark:text-indigo-400" />
                    Department Morale Benchmark
                  </h3>
                  <p className="text-[11px] text-slate-400 dark:text-slate-400 mt-1 mb-6 text-left font-medium">
                    Silo-by-silo mapping to identify low satisfaction sectors.
                  </p>

                  <div className="h-64">
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={stats.departmentPerformance}>
                        <CartesianGrid strokeDasharray="3 3" vertical={false} stroke="#E2E8F0" opacity={0.3} />
                        <XAxis dataKey="departmentName" tick={{ fontSize: 10, fontWeight: 'semibold' }} stroke="#94A3B8" />
                        <YAxis tick={{ fontSize: 10, fontWeight: 'semibold' }} stroke="#94A3B8" />
                        <Tooltip />
                        <Legend wrapperStyle={{ fontSize: '11px', fontWeight: 'semibold' }} />
                        <Bar type="monotone" name="Avg Satisfaction (%)" dataKey="avgSatisfaction" fill="#3B82F6" radius={[4, 4, 0, 0]} barSize={28} />
                        <Bar type="monotone" name="Reports Volume" dataKey="feedbackCount" fill="#CBD5E1" radius={[4, 4, 0, 0]} barSize={12} />
                      </BarChart>
                    </ResponsiveContainer>
                  </div>
                </div>

                {/* Top Extracted Topics via Gemini AI */}
                <div className="lg:col-span-5 bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 p-6 rounded-[24px] shadow-sm flex flex-col justify-between">
                  <div>
                    <h3 className="font-extrabold text-slate-850 dark:text-slate-100 text-sm flex items-center gap-2 text-left">
                      <Activity className="w-4 h-4 text-[#4F46E5] dark:text-indigo-400" />
                      Extracted Organizational Issues (AI)
                    </h3>
                    <p className="text-[11px] text-slate-400 dark:text-slate-400 mt-1 mb-6 text-left font-medium">
                      Categorical focus topics extracted automatically from qualitative text by Gemini.
                    </p>

                    <div className="space-y-4">
                      {stats.topIssues.length === 0 ? (
                        <div className="text-center p-8 text-xs text-slate-400 dark:text-slate-500 font-semibold">
                          No topics extracted yet. Submit feedback reports to start pipeline.
                        </div>
                      ) : (
                        stats.topIssues.map((issue, index) => (
                          <div key={issue.topic} className="space-y-1.5 text-left">
                            <div className="flex justify-between items-center text-xs">
                              <span className="font-extrabold text-slate-700 dark:text-slate-300 uppercase tracking-wide text-[10px]">
                                {issue.topic}
                              </span>
                              <span className="font-bold text-[#4F46E5] dark:text-indigo-300 bg-indigo-50 dark:bg-indigo-950/40 px-2 py-0.5 rounded-lg border border-indigo-100/40 text-[9px]">
                                {issue.count} mention{issue.count !== 1 ? 's' : ''}
                              </span>
                            </div>
                            <div className="w-full bg-slate-100 dark:bg-slate-800 h-2 rounded-full overflow-hidden">
                              <div 
                                className="bg-gradient-to-r from-indigo-500 to-purple-600 h-full rounded-full" 
                                style={{ width: `${(issue.count / Math.max(stats.totalFeedback, 1)) * 100}%` }}
                              ></div>
                            </div>
                          </div>
                        ))
                      )}
                    </div>
                  </div>

                  <div className="pt-6 border-t border-slate-100 dark:border-slate-800 mt-6">
                    <button
                      onClick={handleExportCSV}
                      className="w-full py-2.5 bg-slate-800 dark:bg-slate-700 hover:bg-slate-900 text-white font-bold text-xs uppercase tracking-wider rounded-xl flex items-center justify-center gap-2 transition-all cursor-pointer shadow-sm"
                    >
                      <ArrowDownToLine className="w-4 h-4" />
                      Export Morale Analytics CSV
                    </button>
                  </div>
                </div>

              </div>

            </div>
          )}

          {/* ============================================================== */}
          {/* VIEW: ALL FEEDBACKS TIMELINE (Interactive search/filter) */}
          {/* ============================================================== */}
          {hrTab === 'feedback' && (
            <div className="space-y-6" id="view_feedbacks_timeline">
              
              {/* Premium filter tray */}
              <div className="bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 p-5 rounded-[24px] shadow-sm">
                <form onSubmit={handleApplyFeedbackFilters} className="grid grid-cols-1 md:grid-cols-4 gap-4 items-end">
                  
                  <div className="text-left">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Morale Sentiment</label>
                    <select
                      value={filterSentiment}
                      onChange={(e) => setFilterSentiment(e.target.value)}
                      className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 dark:text-slate-100 font-bold"
                    >
                      <option value="">All Sentiments</option>
                      <option value="positive">🟢 Positive Only</option>
                      <option value="neutral">🟡 Neutral Only</option>
                      <option value="negative">🔴 Negative Only</option>
                    </select>
                  </div>

                  <div className="text-left">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Burnout Level</label>
                    <select
                      value={filterBurnout}
                      onChange={(e) => setFilterBurnout(e.target.value)}
                      className="w-full p-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 dark:text-slate-100 font-bold"
                    >
                      <option value="">All Burnout Risks</option>
                      <option value="low">Low Risk</option>
                      <option value="medium">Medium Risk</option>
                      <option value="high">High Risk</option>
                    </select>
                  </div>

                  <div className="text-left">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Search Keywords</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400 dark:text-slate-500">
                        <Search className="w-4 h-4" />
                      </span>
                      <input
                        type="text"
                        value={searchFeedback}
                        onChange={(e) => setSearchFeedback(e.target.value)}
                        placeholder="Search text keywords..."
                        className="w-full pl-10 pr-3 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 dark:text-slate-100 font-semibold"
                      />
                    </div>
                  </div>

                  <div className="flex gap-2">
                    <button
                      type="submit"
                      className="flex-1 py-2.5 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer"
                    >
                      <Filter className="w-3.5 h-3.5" />
                      <span>Filter</span>
                    </button>
                    <button
                      type="button"
                      onClick={handleExportCSV}
                      className="p-2.5 bg-slate-100 dark:bg-slate-800 hover:bg-slate-200 dark:hover:bg-slate-700 text-slate-700 dark:text-slate-300 font-bold rounded-xl flex items-center justify-center cursor-pointer border border-slate-200/40 dark:border-slate-700"
                      title="Export records to CSV"
                    >
                      <ArrowDownToLine className="w-4.5 h-4.5" />
                    </button>
                  </div>

                </form>
              </div>

              {/* Feedback cards timeline list */}
              <div className="bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 rounded-[24px] shadow-sm overflow-hidden">
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {feedbacks.length === 0 ? (
                    <div className="p-12 text-center text-xs text-slate-400 dark:text-slate-500 flex flex-col items-center gap-2 font-semibold">
                      <MessageSquare className="w-7 h-7 text-slate-300 dark:text-slate-600" />
                      <span>No feedback records found matching parameters.</span>
                    </div>
                  ) : (
                    feedbacks.map((fb) => (
                      <div key={fb.id} className="p-6 transition-all hover:bg-slate-50/30 dark:hover:bg-slate-800/20 text-left">
                        <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                          
                          {/* Left name/anonymity details */}
                          <div className="space-y-1">
                            <div className="flex items-center gap-2">
                              <span className="font-extrabold text-slate-800 dark:text-slate-100 text-sm">
                                {fb.anonymous ? 'Anonymous Employee' : fb.employeeName}
                              </span>
                              <span className="text-[9px] text-slate-400 dark:text-slate-500 bg-slate-100 dark:bg-slate-800 border border-slate-200/60 dark:border-slate-700/60 px-2 py-0.5 font-mono rounded">
                                ID: {fb.id}
                              </span>
                            </div>
                            <div className="flex items-center gap-3 text-xs text-slate-500 dark:text-slate-400">
                              <span className="font-bold text-[#4F46E5] dark:text-indigo-400">{fb.departmentName}</span>
                              <span className="font-mono text-[10px] text-slate-400 dark:text-slate-500">
                                {new Date(fb.createdAt).toLocaleDateString()} at {new Date(fb.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                              </span>
                            </div>
                          </div>

                          {/* Right side Pill ratings and burnout diagnostics */}
                          <div className="flex items-center gap-2 flex-wrap">
                            {fb.analysis && (
                              <>
                                <span className={`px-2.5 py-0.5 text-[9px] rounded-full uppercase font-black tracking-widest border ${getSentimentPillStyle(fb.analysis.sentiment)}`}>
                                  {fb.analysis.sentiment}
                                </span>
                                <span className={`px-2.5 py-0.5 text-[9px] rounded-full uppercase border font-black tracking-wide ${getBurnoutPillStyle(fb.analysis.burnoutRisk)}`}>
                                  Burnout: {fb.analysis.burnoutRisk}
                                </span>
                                <span className="text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 text-slate-800 dark:text-slate-200 px-2 py-0.5 font-black rounded-lg text-[10px]">
                                  Satisfaction: {fb.analysis.satisfactionScore}%
                                </span>
                              </>
                            )}
                            <button
                              onClick={() => setExpandedFbId(expandedFbId === fb.id ? null : fb.id)}
                              className="p-1.5 text-slate-400 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer text-xs font-black flex items-center gap-0.5"
                            >
                              {expandedFbId === fb.id ? 'Collapse Report' : 'Inspect AI Report'}
                              <ChevronRight className={`w-3.5 h-3.5 transform transition-transform ${expandedFbId === fb.id ? 'rotate-90' : ''}`} />
                            </button>
                          </div>
                        </div>

                        {/* Original Text Report Card */}
                        <div className="mt-3 bg-slate-50 dark:bg-slate-850 p-4 rounded-2xl border border-slate-200/50 dark:border-slate-700/80 max-w-5xl text-xs text-slate-600 dark:text-slate-300 leading-relaxed font-semibold italic">
                          "{fb.text}"
                        </div>

                        {/* Expanded Gemini Report Details */}
                        {expandedFbId === fb.id && fb.analysis && (
                          <div className="mt-4 p-5 bg-gradient-to-br from-[#1E1B4B] via-[#0F172A] to-[#1E293B] text-white rounded-2xl grid grid-cols-1 md:grid-cols-12 gap-6 border border-slate-800 dark:border-slate-700 animate-slide-down shadow-xl">
                            
                            {/* Breakdown */}
                            <div className="md:col-span-4 space-y-4 text-left border-r border-white/10 pr-4">
                              <h4 className="font-extrabold text-[10px] text-indigo-300 uppercase tracking-widest flex items-center gap-1.5 pb-2 border-b border-white/10">
                                <Sliders className="w-3.5 h-3.5 text-indigo-400" />
                                Morale Breakdown
                              </h4>

                              <div className="space-y-3.5 pt-1">
                                <div>
                                  <span className="text-[9px] text-indigo-300 font-bold uppercase tracking-wider block">Diagnostics Score</span>
                                  <div className="text-lg font-black text-slate-100 flex items-baseline gap-1 mt-0.5">
                                    {fb.analysis.satisfactionScore} <span className="text-[10px] text-slate-400 font-bold">/ 100</span>
                                  </div>
                                </div>

                                <div>
                                  <span className="text-[9px] text-indigo-300 font-bold uppercase tracking-wider block">Detected Emotion</span>
                                  <div className="text-xs text-slate-200 uppercase font-extrabold tracking-wider mt-0.5 bg-white/5 inline-block px-2 py-0.5 rounded border border-white/5">
                                    {fb.analysis.emotion || 'Unspecified'}
                                  </div>
                                </div>

                                <div>
                                  <span className="text-[9px] text-indigo-300 font-bold uppercase tracking-wider block">Extracted Topics</span>
                                  <div className="flex flex-wrap gap-1 mt-1.5">
                                    {fb.analysis.topics.map((t, i) => (
                                      <span key={i} className="px-1.5 py-0.5 bg-white/10 text-white text-[9px] font-bold uppercase rounded border border-white/5">
                                        {t}
                                      </span>
                                    ))}
                                  </div>
                                </div>
                              </div>
                            </div>

                            {/* Detailed summary and Actionable recommendation list */}
                            <div className="md:col-span-8 space-y-4 text-left">
                              <div>
                                <span className="text-[10px] text-indigo-300 uppercase font-black tracking-widest block">AI Diagnostic Summary</span>
                                <p className="text-xs text-slate-200 leading-relaxed font-semibold mt-1">
                                  {fb.analysis.summary}
                                </p>
                              </div>

                              <div className="pt-4 border-t border-white/10">
                                <span className="text-[10px] text-indigo-300 uppercase font-black tracking-widest flex items-center gap-1.5 mb-2">
                                  <ShieldCheck className="w-3.5 h-3.5 text-emerald-400 animate-pulse" />
                                  Actionable HR Intervention Recommendations
                                </span>
                                <ul className="space-y-2">
                                  {fb.analysis.recommendations.map((rec, i) => (
                                    <li key={i} className="text-xs text-slate-100 leading-relaxed flex items-start gap-2 bg-white/5 p-2.5 rounded-xl border border-white/5">
                                      <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 shrink-0 mt-1.5"></span>
                                      <span>{rec}</span>
                                    </li>
                                  ))}
                                </ul>
                              </div>
                            </div>

                          </div>
                        )}

                      </div>
                    ))
                  )}
                </div>
              </div>

            </div>
          )}

          {/* ============================================================== */}
          {/* VIEW: EMPLOYEE DIRECTORY */}
          {/* ============================================================== */}
          {hrTab === 'employees' && (
            <div className="space-y-6" id="view_employee_directory">
              
              {/* Directory Filter Bar */}
              <div className="bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 p-4 rounded-[24px] shadow-sm flex flex-col sm:flex-row items-center justify-between gap-4">
                <div className="relative max-w-md w-full text-left">
                  <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400 dark:text-slate-500">
                    <Search className="w-4 h-4" />
                  </span>
                  <input
                    type="text"
                    value={searchEmployee}
                    onChange={(e) => setSearchEmployee(e.target.value)}
                    placeholder="Search staff accounts by name or corporate email..."
                    className="w-full pl-10 pr-3 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-850 dark:text-slate-100 font-semibold"
                  />
                </div>
                <span className="text-[11px] text-slate-500 dark:text-slate-400 font-extrabold uppercase tracking-wider bg-slate-55 px-3 py-1 rounded-full border">
                  Total matches: {employees.filter(e => e.name.toLowerCase().includes(searchEmployee.toLowerCase())).length} accounts
                </span>
              </div>

              {/* Data Grid table */}
              <div className="bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 rounded-[24px] shadow-sm overflow-hidden">
                <div className="overflow-x-auto">
                  <table className="w-full text-left border-collapse">
                    <thead>
                      <tr className="bg-slate-50/70 dark:bg-slate-850/50 border-b border-slate-100 dark:border-slate-800 text-[10px] font-black text-slate-400 uppercase tracking-widest">
                        <th className="p-4 pl-6">Staff Member Info</th>
                        <th className="p-4">Department Segment</th>
                        <th className="p-4">Authorization Scope</th>
                        <th className="p-4">Joined Date</th>
                        <th className="p-4">Operational Status</th>
                        <th className="p-4 pr-6 text-right">Account Actions</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-100 dark:divide-slate-800 text-xs text-slate-600 dark:text-slate-300">
                      {employees
                        .filter(e => e.name.toLowerCase().includes(searchEmployee.toLowerCase()) || e.email.toLowerCase().includes(searchEmployee.toLowerCase()))
                        .map((emp) => (
                          <tr key={emp.id} className="hover:bg-slate-50/30 dark:hover:bg-slate-800/20 transition-colors">
                            <td className="p-4 pl-6">
                              <div className="space-y-0.5 text-left">
                                <span className="font-extrabold text-slate-800 dark:text-slate-100 text-sm block">{emp.name}</span>
                                <span className="text-slate-400 dark:text-slate-500 font-bold font-mono text-[10px]">{emp.email}</span>
                              </div>
                            </td>
                            <td className="p-4 font-bold text-slate-800 dark:text-slate-200">
                              {departments.find(d => d.id === emp.departmentId)?.name || 'Unassigned'}
                            </td>
                            <td className="p-4">
                              <span className={`px-2.5 py-0.5 rounded-full font-black uppercase tracking-wider text-[9px] border ${
                                emp.role === 'hr' 
                                  ? 'bg-indigo-50 dark:bg-indigo-950/40 text-[#4F46E5] dark:text-indigo-400 border-indigo-100/40' 
                                  : 'bg-slate-100 dark:bg-slate-800 text-slate-700 dark:text-slate-400 border-slate-200/20'
                              }`}>
                                {emp.role}
                              </span>
                            </td>
                            <td className="p-4 font-mono text-[10px] text-slate-400 dark:text-slate-500">
                              {new Date(emp.createdAt).toLocaleDateString()}
                            </td>
                            <td className="p-4">
                              <span className={`inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full text-[9px] font-black uppercase border ${
                                emp.status === 'active' 
                                  ? 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-800 dark:text-emerald-400 border-emerald-100/40' 
                                  : 'bg-rose-50 dark:bg-rose-950/40 text-rose-800 dark:text-rose-400 border-rose-100/40'
                              }`}>
                                <span className={`w-1.5 h-1.5 rounded-full ${emp.status === 'active' ? 'bg-emerald-500 animate-pulse' : 'bg-rose-500'}`}></span>
                                {emp.status}
                              </span>
                            </td>
                            <td className="p-4 pr-6 text-right">
                              {emp.id === 'emp_admin' ? (
                                <span className="text-[10px] text-slate-400 dark:text-slate-500 font-extrabold uppercase tracking-widest">System Root</span>
                              ) : (
                                <button
                                  onClick={() => handleToggleEmployee(emp.id)}
                                  className={`px-3 py-1.5 rounded-lg text-[9px] font-black uppercase tracking-widest cursor-pointer border transition-all ${
                                    emp.status === 'active' 
                                      ? 'bg-rose-50 dark:bg-rose-950/20 border-rose-100 dark:border-rose-900/30 text-rose-700 dark:text-rose-400 hover:bg-rose-100' 
                                      : 'bg-emerald-50 dark:bg-emerald-950/20 border-emerald-100 dark:border-emerald-900/30 text-emerald-700 dark:text-emerald-400 hover:bg-emerald-100'
                                  }`}
                                >
                                  {emp.status === 'active' ? 'Suspend Account' : 'Activate Account'}
                                </button>
                              )}
                            </td>
                          </tr>
                        ))}
                    </tbody>
                  </table>
                </div>
              </div>

            </div>
          )}

          {/* ============================================================== */}
          {/* VIEW: DEPARTMENTS MANAGER */}
          {/* ============================================================== */}
          {hrTab === 'departments' && (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="view_departments">
              
              {/* Left col: Add new department form */}
              <div className="lg:col-span-5 bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 p-6 rounded-[24px] shadow-sm space-y-5 text-left">
                <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                  <div className="p-2 bg-indigo-50 dark:bg-indigo-950 text-[#4F46E5] dark:text-indigo-400 rounded-xl border border-indigo-100/40">
                    <Plus className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-850 dark:text-slate-100 text-sm">Add Corporate Department</h3>
                    <p className="text-[11px] text-slate-400 dark:text-slate-400 font-medium">Create organizational segments for feedback metrics routing.</p>
                  </div>
                </div>

                {deptFormSuccess && (
                  <div className="p-3 bg-emerald-50 dark:bg-emerald-950/50 text-emerald-800 dark:text-emerald-400 border border-emerald-100 rounded-xl text-xs font-semibold flex items-center gap-1.5">
                    <CheckCircle2 className="w-4 h-4 text-emerald-600" />
                    <span>{deptFormSuccess}</span>
                  </div>
                )}

                <form onSubmit={handleCreateDepartment} className="space-y-4">
                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Department Name</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                        <Building className="w-4 h-4" />
                      </span>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Finance & Wealth Operations"
                        value={newDeptName}
                        onChange={(e) => setNewDeptName(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 dark:text-slate-100 font-semibold"
                      />
                    </div>
                  </div>

                  <div>
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest mb-1.5">Lead / Manager Name</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400">
                        <Users className="w-4 h-4" />
                      </span>
                      <input
                        type="text"
                        required
                        placeholder="e.g. Donna Paulsen"
                        value={newDeptManager}
                        onChange={(e) => setNewDeptManager(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50 dark:bg-slate-800 border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-800 dark:text-slate-100 font-semibold"
                      />
                    </div>
                  </div>

                  <button
                    type="submit"
                    className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-md flex items-center justify-center gap-1.5 cursor-pointer hover:scale-[1.01] active:scale-95 transition-all duration-150"
                  >
                    <Plus className="w-4 h-4" />
                    <span>Initialize Department</span>
                  </button>
                </form>
              </div>

              {/* Right col: List of active departments */}
              <div className="lg:col-span-7 bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 rounded-[24px] shadow-sm overflow-hidden text-left">
                <div className="p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-850/30">
                  <h3 className="font-extrabold text-slate-850 dark:text-slate-100 text-sm">Active Departments ({departments.length})</h3>
                  <p className="text-[11px] text-slate-400 dark:text-slate-400 font-medium mt-0.5">Continuous diagnostics tracks routing metadata for following segments.</p>
                </div>

                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {departments.map((dept) => (
                    <div key={dept.id} className="p-4.5 flex items-center justify-between text-left hover:bg-slate-50/20 dark:hover:bg-slate-800/10 transition-colors">
                      <div className="space-y-1">
                        <span className="font-extrabold text-slate-800 dark:text-slate-100 text-sm block">{dept.name}</span>
                        <div className="flex items-center gap-2 text-xs text-slate-400 dark:text-slate-500 font-semibold">
                          <span className="text-slate-600 dark:text-slate-400 font-bold">Manager:</span> {dept.managerName}
                        </div>
                      </div>
                      <span className="text-[10px] text-slate-400 dark:text-slate-500 bg-slate-50 dark:bg-slate-800 border px-2.5 py-0.5 rounded-lg font-mono">
                        ID: {dept.id}
                      </span>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

          {/* ============================================================== */}
          {/* VIEW: SECURITY AUDIT LOGS */}
          {/* ============================================================== */}
          {hrTab === 'logs' && (
            <div className="space-y-6" id="view_logs">
              
              <div className="bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 p-5 rounded-[24px] shadow-sm text-left">
                <h3 className="font-extrabold text-slate-850 dark:text-slate-100 text-sm flex items-center gap-2">
                  <Activity className="w-4.5 h-4.5 text-[#4F46E5]" />
                  System Security Audit Trail
                </h3>
                <p className="text-[11px] text-slate-400 dark:text-slate-400 mt-1 font-medium">
                  Strict chronological logs of workspace events, corporate authorization changes, registration flows, and reset events.
                </p>
              </div>

              {/* Log Timeline List */}
              <div className="bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 rounded-[24px] shadow-sm overflow-hidden text-left">
                <div className="divide-y divide-slate-100 dark:divide-slate-800">
                  {activityLogs.map((log) => (
                    <div key={log.id} className="p-4.5 flex items-start gap-3 text-xs hover:bg-slate-50/20 dark:hover:bg-slate-800/10 transition-colors">
                      <div className="p-2 bg-slate-50 dark:bg-slate-800 rounded-xl text-slate-500 dark:text-slate-400 mt-0.5 shrink-0 border border-slate-100 dark:border-slate-700">
                        <Clock className="w-4 h-4" />
                      </div>
                      <div className="flex-1 space-y-1">
                        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center gap-1">
                          <span className="font-extrabold text-slate-850 dark:text-slate-100">
                            {log.userName} <span className="font-mono text-[10px] text-slate-400">({log.userId})</span>
                          </span>
                          <span className="font-mono text-[9px] text-slate-400 dark:text-slate-500">
                            {new Date(log.createdAt).toLocaleString()}
                          </span>
                        </div>
                        <p className="text-[11px] text-slate-600 dark:text-slate-300 font-semibold">{log.details}</p>
                        <span className="inline-block px-2 py-0.5 bg-slate-100 dark:bg-slate-800 border border-slate-200/50 dark:border-slate-700/60 text-[9px] text-slate-500 dark:text-slate-400 font-black uppercase rounded font-mono mt-1">
                          {log.action}
                        </span>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

            </div>
          )}

        </div>

      </div>

    </div>
  );
}
