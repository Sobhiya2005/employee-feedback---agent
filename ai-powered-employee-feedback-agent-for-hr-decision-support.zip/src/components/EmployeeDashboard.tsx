import React, { useState, useEffect } from 'react';
import { 
  Sparkles, 
  Send, 
  History, 
  User, 
  Calendar, 
  Smile, 
  ShieldCheck, 
  HelpCircle, 
  Star, 
  AlertTriangle, 
  BookOpen, 
  Clock, 
  Lightbulb, 
  ChevronRight, 
  Building, 
  CheckCircle2,
  ChevronLeft,
  Lock,
  LockKeyhole
} from 'lucide-react';
import { Employee, Department, Feedback } from '../types';

interface EmployeeDashboardProps {
  user: Employee;
  token: string;
  onRefreshNotifications: () => void;
}

export default function EmployeeDashboard({ user, token, onRefreshNotifications }: EmployeeDashboardProps) {
  const [departments, setDepartments] = useState<Department[]>([]);
  const [history, setHistory] = useState<Feedback[]>([]);
  
  // Submit feedback state
  const [rating, setRating] = useState(5);
  const [text, setText] = useState('');
  const [anonymous, setAnonymous] = useState(false);
  const [departmentId, setDepartmentId] = useState('');
  
  const [loading, setLoading] = useState(false);
  const [latestAnalysis, setLatestAnalysis] = useState<any>(null);
  const [activeTab, setActiveTab] = useState<'submit' | 'history'>('submit');
  const [expandedFeedbackId, setExpandedFeedbackId] = useState<string | null>(null);

  // Success state for submitted feedback
  const [submitSuccess, setSubmitSuccess] = useState(false);

  // Sidebar collapsible state
  const [isSidebarCollapsed, setIsSidebarCollapsed] = useState(false);

  useEffect(() => {
    // Load departments
    fetch('/api/departments')
      .then(res => res.json())
      .then(data => {
        setDepartments(data);
        if (data.length > 0) setDepartmentId(data[0].id);
      })
      .catch(err => console.error('Error fetching departments:', err));

    // Load user feedback history
    fetchHistory();
  }, [token]);

  const fetchHistory = () => {
    fetch('/api/feedbacks/my', {
      headers: { 'Authorization': `Bearer ${token}` }
    })
      .then(res => res.json())
      .then(data => {
        if (Array.isArray(data)) {
          setHistory(data);
        }
      })
      .catch(err => console.error('Error fetching history:', err));
  };

  const handleSubmitFeedback = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!text.trim()) return;

    setLoading(true);
    setSubmitSuccess(false);
    setLatestAnalysis(null);

    try {
      const response = await fetch('/api/feedbacks', {
        method: 'POST',
        headers: { 
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${token}`
        },
        body: JSON.stringify({ rating, text, anonymous, departmentId })
      });
      const data = await response.json();

      if (response.ok) {
        setSubmitSuccess(true);
        setText('');
        setRating(5);
        setLatestAnalysis(data.analysis);
        fetchHistory();
        onRefreshNotifications(); // update notifications trigger
      }
    } catch (err) {
      console.error('Error submitting feedback:', err);
    } finally {
      setLoading(false);
    }
  };

  const getSentimentStyle = (sentiment?: string) => {
    switch (sentiment) {
      case 'positive': return 'bg-emerald-50 dark:bg-emerald-950/40 text-emerald-700 dark:text-emerald-400 border-emerald-100/40';
      case 'negative': return 'bg-rose-50 dark:bg-rose-950/40 text-rose-700 dark:text-rose-400 border-rose-100/40';
      default: return 'bg-amber-50 dark:bg-amber-950/40 text-amber-700 dark:text-amber-400 border-amber-100/40';
    }
  };

  const getBurnoutStyle = (risk?: string) => {
    switch (risk) {
      case 'high': return 'bg-rose-100 dark:bg-rose-950 text-rose-950 dark:text-rose-300 font-extrabold border-rose-200/50';
      case 'medium': return 'bg-amber-100 dark:bg-amber-950/50 text-amber-950 dark:text-amber-300 font-bold border-amber-200/50';
      default: return 'bg-emerald-100 dark:bg-emerald-950/50 text-emerald-950 dark:text-emerald-300 font-semibold border-emerald-200/50';
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#0F172A] text-slate-800 dark:text-slate-100 font-sans transition-colors duration-300" id="employee_dashboard_workspace">
      
      {/* Outer layout wrapper */}
      <div className="flex flex-col lg:flex-row max-w-7xl mx-auto px-4 sm:px-6 py-6 gap-6" id="employee_dashboard_layout">
        
        {/* Collapsible Sidebar - visible on desktop */}
        <aside 
          className={`hidden lg:flex flex-col bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 rounded-[24px] p-5 shrink-0 text-slate-500 dark:text-slate-400 shadow-xl space-y-6 self-start sticky top-20 transition-all duration-300 ${
            isSidebarCollapsed ? 'w-20' : 'w-64'
          }`} 
          id="employee_sidebar"
        >
          {/* Sidebar Top Header with Collapse toggle */}
          <div className="flex items-center justify-between pb-4 border-b border-slate-100 dark:border-slate-800">
            {!isSidebarCollapsed && (
              <div className="space-y-0.5 text-left animate-fade-in">
                <span className="text-[9px] uppercase font-black tracking-widest text-indigo-600 dark:text-indigo-400">Employee Workspace</span>
                <h3 className="font-extrabold text-slate-800 dark:text-slate-100 text-sm tracking-tight">Feedback Hub</h3>
              </div>
            )}
            
            <button
              onClick={() => setIsSidebarCollapsed(!isSidebarCollapsed)}
              className="p-1.5 hover:bg-slate-50 dark:hover:bg-slate-800 rounded-lg text-slate-400 hover:text-indigo-600 transition-all ml-auto cursor-pointer border border-slate-100 dark:border-slate-800"
              title={isSidebarCollapsed ? "Expand Sidebar" : "Collapse Sidebar"}
            >
              {isSidebarCollapsed ? <ChevronRight className="w-4 h-4" /> : <ChevronLeft className="w-4 h-4" />}
            </button>
          </div>

          {/* Navigation Links */}
          <nav className="flex flex-col gap-1.5">
            {[
              { id: 'submit', label: 'Submit Feedback', icon: <Send className="w-4.5 h-4.5" /> },
              { id: 'history', label: `History Log (${history.length})`, icon: <History className="w-4.5 h-4.5" /> }
            ].map((tab) => {
              const active = activeTab === tab.id;
              return (
                <button
                  key={tab.id}
                  onClick={() => setActiveTab(tab.id as any)}
                  className={`w-full py-3 rounded-xl text-xs font-bold flex items-center transition-all cursor-pointer border-l-2 text-left ${
                    isSidebarCollapsed ? 'justify-center px-0' : 'px-4'
                  } ${
                    active 
                      ? 'bg-indigo-500/5 text-indigo-600 dark:text-indigo-400 border-indigo-500 bg-slate-855' 
                      : 'border-transparent text-slate-500 hover:text-slate-850 dark:hover:text-slate-200 hover:bg-slate-50/50 dark:hover:bg-slate-800/40'
                  }`}
                  title={isSidebarCollapsed ? tab.label : ''}
                >
                  <span className={`${active ? 'text-indigo-600 dark:text-indigo-400' : 'text-slate-400 dark:text-slate-500'} shrink-0`}>
                    {tab.icon}
                  </span>
                  {!isSidebarCollapsed && <span className="ml-3 animate-fade-in">{tab.label}</span>}
                </button>
              );
            })}
          </nav>

          {/* Sidebar Status Footer */}
          {!isSidebarCollapsed && (
            <div className="pt-6 border-t border-slate-100 dark:border-slate-800 text-[10px] text-slate-400 dark:text-slate-500 space-y-2.5 text-left animate-fade-in">
              <div className="flex items-center gap-2">
                <span className="w-2 h-2 rounded-full bg-emerald-500 animate-pulse"></span>
                <span className="font-semibold text-slate-650 dark:text-slate-400">Encrypted Gateway</span>
              </div>
              <div className="font-mono text-[9px]">Ver: 1.5.0 • SSL Secured</div>
            </div>
          )}
        </aside>

        {/* Main Workspace Frame */}
        <div className="flex-1 min-w-0 space-y-6">
          
          {/* Workspace Header */}
          <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-6 pb-5 border-b border-slate-100 dark:border-slate-800 text-left">
            <div>
              <h1 className="text-2xl font-black text-slate-850 dark:text-slate-100 tracking-tight flex items-center gap-2">
                Workspace Feedback Room
                <span className="text-[10px] bg-emerald-50 dark:bg-emerald-950 text-emerald-700 dark:text-emerald-300 font-bold px-2 py-0.5 rounded-md border border-emerald-100 dark:border-emerald-900/30 uppercase tracking-wider font-mono flex items-center gap-1">
                  <Lock className="w-3 h-3" /> Anonymous Allowed
                </span>
              </h1>
              <p className="text-xs text-slate-400 dark:text-slate-400 mt-1 font-semibold">
                Submit secure workspace feedback. Read instant analytical breakdowns produced by our advanced Gemini decision engine.
              </p>
            </div>

            {/* Mobile / Tablet Top Navigation - Hidden on desktop */}
            <div className="lg:hidden flex bg-slate-100 dark:bg-slate-800 p-1 rounded-2xl border border-slate-200/50 dark:border-slate-700 shrink-0">
              <button 
                onClick={() => setActiveTab('submit')}
                className={`px-4 py-2 rounded-xl text-[10px] font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'submit' 
                    ? 'bg-white dark:bg-[#1E293B] text-indigo-700 dark:text-indigo-400 shadow-sm border border-slate-200/30' 
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-850'
                }`}
              >
                <Send className="w-3.5 h-3.5" />
                Submit Feedback
              </button>
              <button 
                onClick={() => setActiveTab('history')}
                className={`px-4 py-2 rounded-xl text-[10px] font-extrabold flex items-center gap-1.5 transition-all cursor-pointer ${
                  activeTab === 'history' 
                    ? 'bg-white dark:bg-[#1E293B] text-indigo-700 dark:text-indigo-400 shadow-sm border border-slate-200/30' 
                    : 'text-slate-600 dark:text-slate-400 hover:text-slate-850'
                }`}
              >
                <History className="w-3.5 h-3.5" />
                History ({history.length})
              </button>
            </div>
          </div>

          {/* ============================================================== */}
          {/* TAB 1: SUBMIT FEEDBACK VIEW */}
          {/* ============================================================== */}
          {activeTab === 'submit' ? (
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6" id="submit_tab_layout">
              
              {/* Feedback Form (left column) */}
              <div className="lg:col-span-7 bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 p-6 md:p-8 rounded-[24px] shadow-sm space-y-6 text-left" id="feedback_form_container">
                <div className="flex items-center gap-3 pb-4 border-b border-slate-100 dark:border-slate-800">
                  <div className="p-2 bg-indigo-50 dark:bg-indigo-950 text-[#4F46E5] dark:text-indigo-400 rounded-xl border border-indigo-100/40">
                    <BookOpen className="w-5 h-5" />
                  </div>
                  <div>
                    <h3 className="font-extrabold text-slate-850 dark:text-slate-100 text-sm">New Workspace Feedback</h3>
                    <p className="text-[11px] text-slate-400 dark:text-slate-400 font-semibold">Share your suggestions, bottlenecks, or general morale notes.</p>
                  </div>
                </div>

                <form onSubmit={handleSubmitFeedback} className="space-y-6">
                  
                  {/* Rating selector (glowing stars) */}
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Overall Work Satisfaction</label>
                    <div className="flex items-center gap-2">
                      <div className="flex items-center gap-1 bg-slate-50 dark:bg-[#0F172A] p-2.5 rounded-2xl border border-slate-200/60 dark:border-slate-800">
                        {[1, 2, 3, 4, 5].map((star) => (
                          <button
                            type="button"
                            key={star}
                            onClick={() => setRating(star)}
                            className="p-1 transition-transform hover:scale-115 cursor-pointer focus:outline-none"
                          >
                            <Star className={`w-8 h-8 transition-colors ${star <= rating ? 'text-amber-400 fill-amber-400 filter drop-shadow-[0_0_4px_rgba(251,191,36,0.3)]' : 'text-slate-200 dark:text-slate-700'}`} />
                          </button>
                        ))}
                      </div>
                      <span className="text-xs text-slate-500 dark:text-slate-400 font-black ml-2 bg-slate-50 dark:bg-slate-800/50 px-2.5 py-1.5 rounded-lg border border-slate-200/40">
                        {rating === 5 ? 'Excellent 🌟' : rating === 4 ? 'Good 👍' : rating === 3 ? 'Neutral 😐' : rating === 2 ? 'Stressed 😓' : 'Severe Burnout 🚨'}
                      </span>
                    </div>
                  </div>

                  {/* Corporate department focal selector */}
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Target Department Focal Point</label>
                    <div className="relative">
                      <span className="absolute inset-y-0 left-0 flex items-center pl-3.5 text-slate-400 dark:text-slate-500">
                        <Building className="w-4 h-4" />
                      </span>
                      <select
                        value={departmentId}
                        onChange={(e) => setDepartmentId(e.target.value)}
                        className="w-full pl-10 pr-4 py-2.5 text-xs bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-850 dark:text-slate-100 font-bold"
                      >
                        {departments.map((dept) => (
                          <option key={dept.id} value={dept.id}>
                            {dept.name} (Lead: {dept.managerName})
                          </option>
                        ))}
                      </select>
                    </div>
                  </div>

                  {/* Feedback text area */}
                  <div className="space-y-2">
                    <label className="block text-[10px] font-black text-slate-400 uppercase tracking-widest">Detailed Qualitative feedback</label>
                    <textarea
                      required
                      rows={6}
                      placeholder="Be specific! Let us know what's going well or what is causing stress. The Gemini decision agent analyzes this text to extract diagnostic topics and recommendations for HR leads."
                      value={text}
                      onChange={(e) => setText(e.target.value)}
                      className="w-full p-4 text-xs bg-slate-50 dark:bg-[#0F172A] border border-slate-200 dark:border-slate-700 rounded-xl focus:outline-none focus:ring-2 focus:ring-indigo-500 text-slate-900 dark:text-slate-100 font-semibold placeholder:text-slate-450 leading-relaxed"
                    ></textarea>
                    <p className="text-[9px] text-slate-400 dark:text-slate-500 leading-normal">
                      Note: Your qualitative comments will be securely routed. To omit your profile identity completely, toggle the anonymity protection block below.
                    </p>
                  </div>

                  {/* End-to-end anonymity protection toggle */}
                  <div className="p-4 bg-slate-50/60 dark:bg-slate-800/40 rounded-2xl border border-slate-200/40 dark:border-slate-700/60 flex items-center justify-between gap-4">
                    <div className="flex gap-3.5 items-start">
                      <input
                        type="checkbox"
                        id="anonymous"
                        checked={anonymous}
                        onChange={(e) => setAnonymous(e.target.checked)}
                        className="mt-1 h-4.5 w-4.5 text-[#4F46E5] dark:text-indigo-400 focus:ring-indigo-500 border-slate-350 rounded cursor-pointer"
                      />
                      <div>
                        <label htmlFor="anonymous" className="text-xs font-black text-slate-800 dark:text-slate-100 cursor-pointer flex items-center gap-1.5">
                          <LockKeyhole className="w-3.5 h-3.5 text-[#4F46E5]" />
                          Submit Feedback Anonymously
                        </label>
                        <p className="text-[10px] text-slate-400 dark:text-slate-500 mt-0.5 leading-normal">
                          Fully strips your email, name, and meta metadata from HR dashboards. Your feedback will be labeled "Anonymous Employee".
                        </p>
                      </div>
                    </div>
                    <div className="p-1.5 bg-white dark:bg-slate-800 border border-slate-200/40 dark:border-slate-700 rounded-xl text-emerald-600 dark:text-emerald-400 shrink-0 shadow-xs">
                      <ShieldCheck className="w-4.5 h-4.5" />
                    </div>
                  </div>

                  {/* Submit CTA button */}
                  <button
                    type="submit"
                    disabled={loading || !text.trim()}
                    className="w-full py-3 bg-gradient-to-r from-indigo-600 to-purple-600 hover:from-indigo-700 hover:to-purple-700 text-white font-bold text-xs uppercase tracking-wider rounded-xl shadow-lg shadow-indigo-100 dark:shadow-none flex items-center justify-center gap-2 transition-all disabled:opacity-50 cursor-pointer active:scale-95"
                  >
                    {loading ? (
                      <div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div>
                    ) : (
                      <>
                        <Sparkles className="w-4 h-4 text-indigo-100" />
                        <span>Initiate Gemini AI Submission Flow</span>
                      </>
                    )}
                  </button>
                </form>

              </div>

              {/* AI Real-time response analysis (right column) */}
              <div className="lg:col-span-5 flex flex-col gap-6" id="ai_results_container">
                {submitSuccess && latestAnalysis ? (
                  <div className="bg-gradient-to-br from-indigo-950 via-[#0F172A] to-[#1E293B] text-white p-6 rounded-[24px] shadow-2xl space-y-6 animate-fade-in relative overflow-hidden border border-slate-800" id="ai_analysis_card">
                    <div className="absolute top-0 right-0 w-32 h-32 bg-indigo-500/10 rounded-full blur-2xl"></div>

                    <div className="flex items-center gap-2.5 pb-4 border-b border-white/10 relative z-10 text-left">
                      <div className="p-1.5 bg-indigo-500/20 text-indigo-300 rounded-lg">
                        <Sparkles className="w-4 h-4 text-indigo-400" />
                      </div>
                      <div>
                        <h3 className="font-extrabold text-sm text-slate-100">Gemini Security Diagnosis</h3>
                        <p className="text-[10px] text-indigo-300">Generated immediately via Pipeline</p>
                      </div>
                      <span className="ml-auto px-2.5 py-0.5 text-[9px] bg-emerald-500/15 text-emerald-400 border border-emerald-500/30 rounded-full font-black uppercase tracking-wider">
                        Secure
                      </span>
                    </div>

                    <div className="space-y-5 text-left relative z-10">
                      
                      {/* Summary */}
                      <div>
                        <span className="text-[9px] uppercase font-black text-indigo-300 tracking-widest block">AI Diagnostic Summary</span>
                        <p className="text-xs text-slate-100 leading-relaxed font-semibold mt-1">
                          {latestAnalysis.summary}
                        </p>
                      </div>

                      {/* Score metrics */}
                      <div className="grid grid-cols-2 gap-4">
                        <div className="p-3 bg-white/5 border border-white/10 rounded-xl">
                          <span className="text-[9px] uppercase font-bold text-indigo-300 tracking-wider block">Satisfaction score</span>
                          <div className="text-lg font-black mt-1 text-slate-100 flex items-baseline gap-1">
                            {latestAnalysis.satisfactionScore} <span className="text-[10px] text-slate-400">/ 100</span>
                          </div>
                          <div className="w-full bg-white/10 h-1.5 rounded-full overflow-hidden mt-2">
                            <div className="bg-indigo-400 h-full rounded-full" style={{ width: `${latestAnalysis.satisfactionScore}%` }}></div>
                          </div>
                        </div>

                        <div className="p-3 bg-white/5 border border-white/10 rounded-xl">
                          <span className="text-[9px] uppercase font-bold text-indigo-300 tracking-wider block">Burnout Prediction</span>
                          <div className="text-sm font-black uppercase tracking-widest mt-1.5 flex items-center gap-1.5">
                            <span className={`w-2.5 h-2.5 rounded-full ${
                              latestAnalysis.burnoutRisk === 'high' ? 'bg-rose-500 animate-pulse' : latestAnalysis.burnoutRisk === 'medium' ? 'bg-amber-400' : 'bg-emerald-400'
                            }`}></span>
                            <span className="text-slate-100">{latestAnalysis.burnoutRisk}</span>
                          </div>
                        </div>
                      </div>

                      {/* sentiment / emotion */}
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <span className="text-[9px] uppercase font-bold text-indigo-300 tracking-wider block">Sentiment</span>
                          <div className="mt-1">
                            <span className={`inline-block px-2.5 py-0.5 text-[9px] font-black uppercase tracking-widest rounded-md ${
                              latestAnalysis.sentiment === 'positive' ? 'bg-emerald-500/20 text-emerald-300' : latestAnalysis.sentiment === 'negative' ? 'bg-rose-500/20 text-rose-300' : 'bg-slate-500/30 text-slate-300'
                            }`}>
                              {latestAnalysis.sentiment}
                            </span>
                          </div>
                        </div>

                        <div>
                          <span className="text-[9px] uppercase font-bold text-indigo-300 tracking-wider block">Primary Emotion</span>
                          <div className="mt-1 flex items-center gap-1 text-xs text-slate-200 font-extrabold uppercase tracking-widest">
                            <Smile className="w-4 h-4 text-indigo-400" />
                            <span>{latestAnalysis.emotion}</span>
                          </div>
                        </div>
                      </div>

                      {/* Topics */}
                      <div>
                        <span className="text-[9px] uppercase font-black text-indigo-300 tracking-widest block">Extracted Topics</span>
                        <div className="flex flex-wrap gap-1 mt-1.5">
                          {latestAnalysis.topics.map((topic: string, i: number) => (
                            <span key={i} className="px-1.5 py-0.5 bg-white/10 text-white text-[9px] font-bold uppercase rounded border border-white/5">
                              {topic}
                            </span>
                          ))}
                        </div>
                      </div>

                      {/* HR recommendations summary */}
                      <div className="pt-4 border-t border-white/10">
                        <span className="text-[9px] uppercase font-black text-indigo-300 tracking-widest flex items-center gap-1 block">
                          <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                          AI Action recommendations
                        </span>
                        <ul className="mt-2.5 space-y-2">
                          {latestAnalysis.recommendations.map((rec: string, i: number) => (
                            <li key={i} className="text-[10px] text-slate-200 leading-normal flex items-start gap-2 bg-white/5 p-2 rounded-xl border border-white/5">
                              <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 shrink-0 mt-1.5"></span>
                              <span>{rec}</span>
                            </li>
                          ))}
                        </ul>
                      </div>

                    </div>
                  </div>
                ) : (
                  <div className="bg-white dark:bg-[#1E293B] border border-dashed border-slate-200 dark:border-slate-800 p-8 rounded-[24px] flex flex-col items-center justify-center text-center space-y-3 h-full min-h-[350px]">
                    <div className="p-4.5 bg-slate-50 dark:bg-[#0F172A] text-slate-400 dark:text-slate-500 rounded-full border border-slate-100 dark:border-slate-800">
                      <Sparkles className="w-8 h-8 text-indigo-500" />
                    </div>
                    <h4 className="font-extrabold text-slate-800 dark:text-slate-200 text-sm">Real-time AI Diagnostic</h4>
                    <p className="text-xs text-slate-400 dark:text-slate-400 max-w-xs leading-relaxed font-semibold">
                      Submit workspace feedback to trigger Google Gemini instantly. The AI will classify emotions, predict burnout risk, and recommend precise guidance paths.
                    </p>
                  </div>
                )}
              </div>

            </div>
          ) : (
            
            // ==============================================================
            // TAB 2: FEEDBACK SUBMISSION HISTORY LOGS
            // ==============================================================
            <div className="bg-white dark:bg-[#1E293B] border border-slate-200/60 dark:border-slate-800/80 rounded-[24px] shadow-sm overflow-hidden text-left" id="history_tab_layout">
              <div className="p-5 border-b border-slate-100 dark:border-slate-800 bg-slate-50/70 dark:bg-slate-850/30">
                <h3 className="font-extrabold text-slate-850 dark:text-slate-100 text-sm">Your feedback Submission Log</h3>
                <p className="text-[11px] text-slate-400 dark:text-slate-400 font-semibold mt-0.5">Review past feedback comments and complete historical AI analytics.</p>
              </div>

              <div className="divide-y divide-slate-100 dark:divide-slate-800">
                {history.length === 0 ? (
                  <div className="p-12 text-center text-xs text-slate-400 dark:text-slate-500 flex flex-col items-center gap-2 font-semibold">
                    <BookOpen className="w-7 h-7 text-slate-300 dark:text-slate-600" />
                    <span>You have not registered any feedback reports in this session.</span>
                  </div>
                ) : (
                  history.map((fb) => (
                    <div key={fb.id} className="p-6 transition-all hover:bg-slate-50/20 dark:hover:bg-slate-800/10">
                      
                      <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
                        {/* Rating stars and target department */}
                        <div className="flex items-center gap-3 flex-wrap">
                          <div className="flex text-amber-400 shrink-0">
                            {Array.from({ length: fb.rating }).map((_, i) => (
                              <Star key={i} className="w-3.5 h-3.5 fill-amber-400 text-amber-400" />
                            ))}
                          </div>
                          <span className="text-xs font-extrabold text-slate-700 dark:text-slate-300">
                            Segment focus: {fb.departmentName}
                          </span>
                          <span className="text-[10px] text-slate-400 dark:text-slate-500 flex items-center gap-1 font-mono font-bold">
                            <Clock className="w-3 h-3" />
                            {new Date(fb.createdAt).toLocaleDateString()}
                          </span>
                          {fb.anonymous && (
                            <span className="px-2 py-0.5 text-[9px] bg-indigo-50 dark:bg-indigo-950 text-[#4F46E5] dark:text-indigo-400 font-black uppercase rounded-lg border border-indigo-100/40">
                              Anonymous Submission
                            </span>
                          )}
                        </div>

                        {/* Analysis pill ratings */}
                        <div className="flex items-center gap-2">
                          {fb.analysis && (
                            <>
                              <span className={`px-2 py-0.5 text-[9px] rounded-md uppercase font-black tracking-widest border ${getSentimentStyle(fb.analysis.sentiment)}`}>
                                {fb.analysis.sentiment}
                              </span>
                              <span className={`px-2 py-0.5 text-[9px] rounded-md uppercase border font-black tracking-wide ${getBurnoutStyle(fb.analysis.burnoutRisk)}`}>
                                Burnout: {fb.analysis.burnoutRisk}
                              </span>
                            </>
                          )}
                          <button 
                            onClick={() => setExpandedFeedbackId(expandedFeedbackId === fb.id ? null : fb.id)}
                            className="p-1.5 text-slate-400 dark:text-slate-400 hover:text-indigo-600 dark:hover:text-indigo-400 rounded-lg hover:bg-slate-100 dark:hover:bg-slate-800 transition-all cursor-pointer text-xs font-black flex items-center gap-0.5"
                          >
                            {expandedFeedbackId === fb.id ? 'Collapse' : 'Inspect AI Report'}
                            <ChevronRight className={`w-3.5 h-3.5 transform transition-transform ${expandedFeedbackId === fb.id ? 'rotate-90' : ''}`} />
                          </button>
                        </div>
                      </div>

                      {/* Body comments card */}
                      <p className="text-xs text-slate-600 dark:text-slate-300 leading-relaxed mt-3 max-w-4xl bg-slate-50 dark:bg-slate-850 p-4 rounded-2xl border border-slate-200/50 dark:border-slate-700/80 font-semibold italic">
                        "{fb.text}"
                      </p>

                      {/* Expandable Gemini diagnostics block */}
                      {expandedFeedbackId === fb.id && fb.analysis && (
                        <div className="mt-4 p-5 bg-gradient-to-br from-[#1E1B4B] via-[#0F172A] to-[#1E293B] text-white rounded-2xl grid grid-cols-1 md:grid-cols-12 gap-6 border border-slate-800 dark:border-slate-700 shadow-xl animate-slide-down">
                          
                          {/* Metrics summary breakdown */}
                          <div className="md:col-span-4 space-y-4 text-left border-r border-white/10 pr-4">
                            <h4 className="font-extrabold text-[10px] text-indigo-300 uppercase tracking-widest flex items-center gap-1.5 pb-2 border-b border-white/10">
                              <Sparkles className="w-3.5 h-3.5 text-amber-400" />
                              AI Diagnostic Breakdown
                            </h4>
                            
                            <div className="space-y-3.5 pt-1">
                              <div>
                                <span className="text-[9px] text-indigo-300 font-bold uppercase tracking-wider block">Satisfaction score</span>
                                <div className="text-lg font-black text-slate-100 flex items-baseline gap-1 mt-0.5">
                                  {fb.analysis.satisfactionScore} <span className="text-[10px] text-slate-400 font-bold">/ 100</span>
                                </div>
                              </div>

                              <div>
                                <span className="text-[9px] text-indigo-300 font-bold uppercase tracking-wider block">Detected Emotion</span>
                                <div className="text-xs text-slate-200 uppercase font-extrabold tracking-wider mt-0.5 bg-white/5 inline-block px-2 py-0.5 rounded border border-white/5">
                                  {fb.analysis.emotion || 'Unspecified'}
                                </div>
                              </div>

                              <div>
                                <span className="text-[9px] text-indigo-300 font-bold uppercase tracking-wider block">Extracted Topics</span>
                                <div className="flex flex-wrap gap-1.5 mt-1.5">
                                  {fb.analysis.topics.map((t: string, i: number) => (
                                    <span key={i} className="px-1.5 py-0.5 bg-white/10 text-white text-[9px] font-bold uppercase rounded border border-white/5">
                                      {t}
                                    </span>
                                  ))}
                                </div>
                              </div>
                            </div>
                          </div>

                          {/* Summary & Recommendations */}
                          <div className="md:col-span-8 text-left space-y-4">
                            <div>
                              <span className="text-[10px] text-indigo-300 uppercase font-black tracking-widest block">AI Diagnostic Summary</span>
                              <p className="text-xs text-slate-200 leading-relaxed font-semibold mt-1">
                                {fb.analysis.summary}
                              </p>
                            </div>

                            <div className="pt-4 border-t border-white/10">
                              <span className="text-[10px] text-indigo-300 uppercase font-black tracking-widest flex items-center gap-1.5 mb-2">
                                <Lightbulb className="w-3.5 h-3.5 text-amber-400" />
                                Interactive Guidance Action recommendations
                              </span>
                              <ul className="space-y-2">
                                {fb.analysis.recommendations.map((rec: string, i: number) => (
                                  <li key={i} className="text-xs text-slate-100 leading-relaxed flex items-start gap-2 bg-white/5 p-2.5 rounded-xl border border-white/5">
                                    <span className="w-1.5 h-1.5 rounded-full bg-indigo-400 shrink-0 mt-1.5"></span>
                                    <span>{rec}</span>
                                  </li>
                                ))}
                              </ul>
                            </div>
                          </div>

                        </div>
                      )}

                    </div>
                  ))
                )}
              </div>
            </div>

          )}

        </div>

      </div>

    </div>
  );
}
