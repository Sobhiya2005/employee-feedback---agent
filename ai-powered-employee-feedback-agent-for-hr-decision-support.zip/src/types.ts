export type Role = 'employee' | 'hr';

export interface Employee {
  id: string;
  name: string;
  email: string;
  role: Role;
  departmentId: string;
  status: 'active' | 'inactive';
  createdAt: string;
}

export interface Department {
  id: string;
  name: string;
  managerName: string;
  createdAt: string;
}

export interface Feedback {
  id: string;
  employeeId: string;
  employeeName?: string; // Optional if submitted anonymously
  departmentId: string;
  departmentName?: string;
  rating: number; // 1 to 5
  text: string;
  anonymous: boolean;
  createdAt: string;
  analysis?: AIAnalysis; // Embedded or joined
}

export interface AIAnalysis {
  id: string;
  feedbackId: string;
  sentiment: 'positive' | 'neutral' | 'negative';
  summary: string;
  topics: string[];
  emotion: 'happy' | 'sad' | 'stressed' | 'frustrated' | 'motivated' | 'confused';
  burnoutRisk: 'low' | 'medium' | 'high';
  satisfactionScore: number; // 0 to 100
  recommendations: string[];
  createdAt: string;
}

export interface Notification {
  id: string;
  recipientId: string; // Employee ID, 'hr', or 'all'
  title: string;
  message: string;
  read: boolean;
  createdAt: string;
}

export interface ActivityLog {
  id: string;
  userId: string;
  userName: string;
  action: string;
  details: string;
  createdAt: string;
}

export interface UserSession {
  user: Employee | null;
  token: string | null;
}

export interface HRDashboardStats {
  totalEmployees: number;
  totalFeedback: number;
  positivePercentage: number;
  negativePercentage: number;
  neutralPercentage: number;
  averageSatisfaction: number;
  burnoutCount: number;
  departmentPerformance: {
    departmentId: string;
    departmentName: string;
    avgSatisfaction: number;
    feedbackCount: number;
  }[];
  monthlyTrends: {
    month: string; // e.g. "Jan", "Feb"
    feedbackCount: number;
    avgSatisfaction: number;
  }[];
  topIssues: {
    topic: string;
    count: number;
  }[];
}
