import React, { useState, useEffect } from 'react';
import { BookOpen, ShieldAlert, Users, Code2, Sparkles, X, Terminal, CheckCircle2 } from 'lucide-react';
import AuthPages from './components/AuthPages';
import Navbar from './components/Navbar';
import EmployeeDashboard from './components/EmployeeDashboard';
import HRDashboard from './components/HRDashboard';
import { Employee } from './types';

export default function App() {
  const [user, setUser] = useState<Employee | null>(null);
  const [token, setToken] = useState<string | null>(null);
  const [refreshTrigger, setRefreshTrigger] = useState(0);

  // Academic support overlay state
  const [showAcademicOverlay, setShowAcademicOverlay] = useState(false);

  useEffect(() => {
    // Attempt automatic session recovery on page reload
    const storedUser = localStorage.getItem('ff_user');
    const storedToken = localStorage.getItem('ff_token');
    
    if (storedUser && storedToken) {
      try {
        setUser(JSON.parse(storedUser));
        setToken(storedToken);
      } catch (e) {
        localStorage.removeItem('ff_user');
        localStorage.removeItem('ff_token');
      }
    }
  }, []);

  const handleLoginSuccess = (loggedInUser: Employee, sessionToken: string) => {
    setUser(loggedInUser);
    setToken(sessionToken);
    localStorage.setItem('ff_user', JSON.stringify(loggedInUser));
    localStorage.setItem('ff_token', sessionToken);
  };

  const handleLogout = () => {
    setUser(null);
    setToken(null);
    localStorage.removeItem('ff_user');
    localStorage.removeItem('ff_token');
  };

  const triggerNotificationRefresh = () => {
    setRefreshTrigger(prev => prev + 1);
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC] dark:bg-[#0F172A] flex flex-col font-sans" id="main_app_wrapper">
      {user && token ? (
        <>
          {/* Main Workspace with authenticated navigation bar */}
          <Navbar 
            user={user} 
            token={token} 
            onLogout={handleLogout} 
            triggerRefresh={refreshTrigger > 0} 
          />
          
          <main className="flex-1 overflow-y-auto">
            {user.role === 'hr' ? (
              <HRDashboard 
                token={token} 
                onRefreshNotifications={triggerNotificationRefresh} 
              />
            ) : (
              <EmployeeDashboard 
                user={user} 
                token={token} 
                onRefreshNotifications={triggerNotificationRefresh} 
              />
            )}
          </main>
        </>
      ) : (
        /* Display the authentication screens if unauthenticated */
        <AuthPages onLoginSuccess={handleLoginSuccess} />
      )}

      {/* Floating Interactive Project documentation Overlay Trigger */}
      <button
        onClick={() => setShowAcademicOverlay(true)}
        className="fixed bottom-6 right-6 p-3.5 bg-indigo-600 text-white rounded-full shadow-2xl hover:bg-indigo-700 transition-all z-40 flex items-center justify-center gap-2 font-semibold text-xs border border-indigo-500 cursor-pointer"
        title="College Project Info Dossier"
        id="academic_dossier_btn"
      >
        <BookOpen className="w-5 h-5 animate-pulse" />
        <span className="hidden sm:inline-block">Project Dossier (Viva Q&A)</span>
      </button>

      {/* College Project Documentation Modal Overlay */}
      {showAcademicOverlay && (
        <div className="fixed inset-0 bg-slate-900/60 backdrop-blur-xs z-50 flex items-center justify-center p-4 animate-fade-in" id="academic_modal">
          <div className="bg-white rounded-3xl shadow-2xl border border-slate-100 max-w-4xl w-full h-[85vh] flex flex-col overflow-hidden relative">
            
            {/* Header */}
            <div className="p-6 border-b border-slate-100 bg-slate-50 flex items-center justify-between">
              <div className="flex items-center gap-2.5 text-left">
                <div className="p-2 bg-indigo-600 rounded-xl text-white">
                  <BookOpen className="w-5 h-5" />
                </div>
                <div>
                  <h3 className="font-extrabold text-slate-800 text-base leading-snug">Project Documentation & Viva Guide</h3>
                  <p className="text-xs text-slate-400">Final Year Engineering Project Presentation Reference</p>
                </div>
              </div>
              <button 
                onClick={() => setShowAcademicOverlay(false)}
                className="p-2 text-slate-400 hover:text-slate-800 hover:bg-slate-100 rounded-xl transition-all cursor-pointer"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            {/* Scrollable Content Pane */}
            <div className="flex-1 overflow-y-auto p-6 md:p-8 space-y-8 text-left text-xs text-slate-600 leading-relaxed">
              
              {/* Architecture Blueprint section */}
              <div className="space-y-3">
                <h4 className="font-black text-slate-800 text-sm uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-100 pb-2">
                  <Terminal className="w-4 h-4 text-indigo-600" />
                  1. Project Synopsis & Scope
                </h4>
                <p>
                  <strong>Title</strong>: AI-Powered Employee Feedback Agent for HR Decision Support <br />
                  <strong>Concept</strong>: Building a software system to gather continuous workspace morale signals. In contrast to manual yearly performance checks, FeedForward analyzes qualitative text reports to forecast fatigue indices, detect burnout risks, and isolate department-wise anomalies in real-time.
                </p>
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4 pt-2">
                  <div className="p-3 bg-indigo-50/60 border border-indigo-100 rounded-xl">
                    <span className="font-bold text-indigo-900 block text-xs">Node.js / React</span>
                    <span className="text-[10px] text-indigo-700">Full-stack Vite architecture serving both React client assets and API endpoints seamlessly.</span>
                  </div>
                  <div className="p-3 bg-indigo-50/60 border border-indigo-100 rounded-xl">
                    <span className="font-bold text-indigo-900 block text-xs">Structured AI Parser</span>
                    <span className="text-[10px] text-indigo-700">Utilizes Google Gemini with structured response parameters to enforce strictly formatted schemas.</span>
                  </div>
                  <div className="p-3 bg-indigo-50/60 border border-indigo-100 rounded-xl">
                    <span className="font-bold text-indigo-900 block text-xs">Safety Gateways</span>
                    <span className="text-[10px] text-indigo-700">Enforces complete privacy layers: submitters can select secure anonymity to hide identifying markers.</span>
                  </div>
                </div>
              </div>

              {/* Database ER Relationships */}
              <div className="space-y-3">
                <h4 className="font-black text-slate-800 text-sm uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-100 pb-2">
                  <Code2 className="w-4 h-4 text-indigo-600" />
                  2. Relational Database Architecture
                </h4>
                <p>The system utilizes a 3NF normalized schema for absolute transactional consistency. A sample DDL schema (`mysql-schema.sql`) is stored in the workspace assets folder.</p>
                <div className="bg-slate-900 text-slate-100 p-4 rounded-xl font-mono text-[10px] space-y-1.5 overflow-x-auto leading-normal">
                  <div>-- SQL SCHEMA BRIEF</div>
                  <div>CREATE TABLE department (id VARCHAR(50) PRIMARY KEY, name VARCHAR(100), manager_name VARCHAR(100));</div>
                  <div>CREATE TABLE employee (id VARCHAR(50) PRIMARY KEY, name VARCHAR(100), email VARCHAR(100) UNIQUE, department_id VARCHAR(50) REFERENCES department(id));</div>
                  <div>CREATE TABLE feedback (id VARCHAR(50) PRIMARY KEY, rating INT, feedback_text TEXT, anonymous BOOLEAN, department_id VARCHAR(50) REFERENCES department(id));</div>
                  <div>CREATE TABLE ai_analysis (id VARCHAR(50) PRIMARY KEY, feedback_id VARCHAR(50) UNIQUE REFERENCES feedback(id), sentiment VARCHAR(20), burnout_risk VARCHAR(20), satisfaction_score INT, recommendations TEXT);</div>
                </div>
              </div>

              {/* Viva Q&A Panel */}
              <div className="space-y-4">
                <h4 className="font-black text-slate-800 text-sm uppercase tracking-wider flex items-center gap-1.5 border-b border-slate-100 pb-2">
                  <ShieldAlert className="w-4 h-4 text-rose-600" />
                  3. Key Academic Viva Q&A
                </h4>
                
                <div className="space-y-3.5 divide-y divide-slate-100">
                  <div className="pt-2">
                    <span className="font-extrabold text-slate-800 block text-xs">Q: What is the main research objective of this feedback agent?</span>
                    <p className="mt-1">A: To build a proactive decision-support agent that converts unstructured corporate text logs into structured metric trends, enabling managers to detect burnout risks and departments dissatisfaction earlier than typical static yearly surveys.</p>
                  </div>

                  <div className="pt-3.5">
                    <span className="font-extrabold text-slate-800 block text-xs">Q: How does the Google Gemini integration ensure consistent outputs?</span>
                    <p className="mt-1">A: We send strict system instructions alongside a structured JSON response schema (`responseMimeType: 'application/json'`). This enforces a mandatory response format, ensuring that the return payload contains precisely typed fields for database insertion without runtime drift.</p>
                  </div>

                  <div className="pt-3.5">
                    <span className="font-extrabold text-slate-800 block text-xs">Q: Explain the burnout risk detection logic.</span>
                    <p className="mt-1">A: Gemini analyzes employee text for linguistic fatigue patterns, such as comments about overwork, prolonged 12-hour schedules, stress, or management neglect. It maps these indices to categorical alert parameters (low, medium, high) and forwards high burnout alerts directly to the HR dashboard.</p>
                  </div>

                  <div className="pt-3.5">
                    <span className="font-extrabold text-slate-800 block text-xs">Q: What is the backup fallback strategy if the Gemini API is unresponsive?</span>
                    <p className="mt-1">A: To guarantee resilient, continuous system operation, the backend features a robust local keyword-matching algorithm that scans inputs for stress markers and provides a formatted local morale diagnostic response if API keys are missing or calls fail.</p>
                  </div>
                </div>
              </div>

              {/* Implementation checklist */}
              <div className="space-y-3 pt-4 border-t border-slate-100">
                <div className="flex items-center gap-2 text-emerald-600">
                  <CheckCircle2 className="w-5 h-5" />
                  <span className="font-bold text-slate-800 text-xs">All project systems are fully compiled & runnable.</span>
                </div>
                <p className="text-[11px] text-slate-400">Review files `/academic-assets/mysql-schema.sql`, `/academic-assets/springboot-backend-guide.md`, and `/academic-assets/documentation.md` for full offline submission assets.</p>
              </div>

            </div>

            {/* Footer */}
            <div className="p-4 bg-slate-50 border-t border-slate-100 text-center">
              <button
                onClick={() => setShowAcademicOverlay(false)}
                className="px-6 py-2 bg-indigo-600 hover:bg-indigo-700 text-white font-bold text-xs rounded-xl shadow-md cursor-pointer transition-all"
              >
                Close Presentation Dossier
              </button>
            </div>
          </div>
        </div>
      )}

    </div>
  );
}
