# AI-Powered Employee Feedback Agent for HR Decision Support
## Final Year Engineering Project - Complete Documentation Dossier

---

## 1. Project Abstract & Synopsis

### Abstract
In modern corporate environments, employee retention and workplace wellness have emerged as primary indicators of organizational success. Conventional yearly or bi-annual reviews often fail to catch high-intensity burnout risks, department morale slippages, and operational bottlenecks in a timely manner. This project, **FeedForward**, introduces an intelligent, continuous **AI-Powered Employee Feedback Agent** designed to serve as an HR Decision Support System. 

By leveraging the **Google Gemini API** (Gemini 3.5 Flash) server-side, the system parses incoming qualitative employee feedback in real-time, automatically extracting multi-dimensional analytics: Sentiment Classifications, Emotion Detection, Topic Frequencies, Burnout Risk Projections, and Satisfaction Indices. The platform provides employees with a secure space to report concerns (supporting structural anonymity gates) while equipping HR managers with visual analytics hubs, comparative department index charts, and audit-logged directories to proactively intervene and mitigate attrition.

### Synopsis
- **Project Type**: Enterprise AI-Driven HR Tech & Morale Analytics
- **Frontend Architecture**: Single Page Application (SPA) using React.js, Tailwind CSS for visual polish, Lucide-React icon arrays, and Recharts for declarative, responsive SVG analytics.
- **Backend Architecture**: Node.js/Express.js (integrated runtime) paired with an SQLite/JSON local database for immediate sandbox execution. A parallel Spring Boot 3.x + JPA + Spring Security specification is supplied for relational MySQL deployments.
- **AI Core**: Google Gemini 3.5 Flash using strict Structured JSON Output Schemas (`responseSchema`) to prevent schema-drift.

---

## 2. System Diagrams (Mermaid Visual Specifications)

These diagrams use Mermaid formatting and can be rendered directly inside VS Code, GitHub, or Mermaid Live Editor.

### A. Entity-Relationship (ER) Diagram
```mermaid
erDiagram
    DEPARTMENT ||--o{ EMPLOYEE : "employs"
    DEPARTMENT ||--o{ FEEDBACK : "focuses"
    EMPLOYEE ||--o{ FEEDBACK : "submits"
    FEEDBACK ||--|| AI_ANALYSIS : "triggers"
    EMPLOYEE ||--o{ ACTIVITY_LOG : "generates"
    
    DEPARTMENT {
        string id PK
        string name
        string managerName
        timestamp createdAt
    }
    EMPLOYEE {
        string id PK
        string name
        string email
        string passwordHash
        string role
        string departmentId FK
        string status
        timestamp createdAt
    }
    FEEDBACK {
        string id PK
        string employeeId FK
        string departmentId FK
        int rating
        text text
        boolean anonymous
        timestamp createdAt
    }
    AI_ANALYSIS {
        string id PK
        string feedbackId FK
        string sentiment
        text summary
        string topics
        string emotion
        string burnoutRisk
        int satisfactionScore
        text recommendations
        timestamp createdAt
    }
```

### B. Use Case Diagram
```mermaid
graph TD
    subgraph Employee Actions
        E[Employee User] --> E1[Register Account]
        E --> E2[Secure Log In]
        E --> E3[Submit Anonymized Feedback]
        E --> E4[View Personal Feedback History]
        E --> E5[Receive Processing Notifications]
    end

    subgraph HR Admin Actions
        HR[HR Administrator] --> HR1[Morale Analytics Hub]
        HR --> HR2[Search & Filter Feedbacks]
        HR --> HR3[Inspect Gemini Recommendation Reports]
        HR --> HR4[Suspend/Activate Staff Accounts]
        HR --> HR5[Define New Organizational Departments]
        HR --> HR6[Export CSV Morale Metrics]
    end

    subgraph AI Processing Engine
        E3 --> AI[Gemini 3.5 Flash Model]
        AI --> A1[Sentiment & Emotion Parser]
        AI --> A2[Burnout Risk Projection]
        AI --> A3[Action Recommendation Draft]
    end
```

### C. Sequence Diagram (Feedback Submission & AI Analysis)
```mermaid
sequenceDiagram
    autonumber
    actor Employee as Staff Member
    participant Client as React Client (Vite)
    participant Server as Express/Spring Server
    participant DB as System Database
    participant AI as Google Gemini API

    Employee->>Client: Compose feedback text & toggles anonymous
    Client->>Server: HTTP POST /api/feedbacks (with Bearer Token)
    Server->>Server: Authenticate JWT Token & Extract User Context
    Server->>DB: Insert raw feedback record (omits name if anonymous)
    Server->>AI: Send feedback text to Gemini 3.5 Flash (with strict JSON Schema)
    AI-->>Server: Return structured JSON (Sentiment, Burnout Risk, Recommendations)
    Server->>DB: Insert AI Analysis record
    Server->>DB: Push notification alerts (High Burnout triggers alert to HR)
    Server-->>Client: Respond 201 Created (Feedback + AI metrics)
    Client-->>Employee: Transition view to display real-time AI summary
```

---

## 3. REST API Specification

### A. Authentication: User Log In
- **Endpoint**: `POST /api/auth/login`
- **Payload Request**:
```json
{
  "email": "employee@company.com",
  "password": "employeepassword"
}
```
- **Success Response (200 OK)**:
```json
{
  "user": {
    "id": "emp_1",
    "name": "John Doe",
    "email": "employee@company.com",
    "role": "employee",
    "departmentId": "dept_it",
    "status": "active",
    "createdAt": "2026-07-07T00:00:00.000Z"
  },
  "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
}
```

### B. Core Operations: Submit Feedback
- **Endpoint**: `POST /api/feedbacks`
- **Headers**: `Authorization: Bearer <token>`
- **Payload Request**:
```json
{
  "rating": 4,
  "text": "The technological stack we use is outstanding, but recent project timelines are creating high work stress.",
  "anonymous": true,
  "departmentId": "dept_it"
}
```
- **Success Response (211 Created)**:
```json
{
  "feedback": {
    "id": "fb_17199999",
    "departmentId": "dept_it",
    "departmentName": "Information Technology",
    "rating": 4,
    "text": "The technological stack...",
    "anonymous": true,
    "createdAt": "2026-07-07T12:00:00.000Z"
  },
  "analysis": {
    "id": "an_17199999",
    "sentiment": "negative",
    "summary": "Employee appreciates current development frameworks but expresses rising tension around immediate release deadlines.",
    "topics": ["Infrastructure", "Workload"],
    "emotion": "stressed",
    "burnoutRisk": "medium",
    "satisfactionScore": 48,
    "recommendations": [
      "Schedule IT workload review sessions.",
      "Promote compensatory resting intervals post-milestone release."
    ]
  }
}
```

---

## 4. Setup & Deployment Playbook

### Running the Node.js Full-Stack Applet (This Workspace)
1. Ensure you have Node.js (v18+) installed.
2. Configure your Google Gemini API Key inside `.env` file at root level:
   ```env
   GEMINI_API_KEY="AIzaSyYourSecretKey..."
   ```
3. Boot the Express + Vite server in development mode:
   ```bash
   npm run dev
   ```
4. Build static distribution and bundle the server for production deployment:
   ```bash
   npm run build
   ```
5. Initiate production server:
   ```bash
   npm start
   ```

### Deploying to Spring Boot + MySQL (For college submissions)
1. Ensure Java 21, Maven 3.x, and MySQL Server are installed.
2. Import the supplied SQL schema (`mysql-schema.sql`) into your MySQL server to initialize databases and sample seeds.
3. Configure `src/main/resources/application.properties` with correct database credentials and your Gemini API key.
4. Open the project root in terminal and compile using Maven:
   ```bash
   mvn clean install
   ```
5. Run the Spring Boot application:
   ```bash
   mvn spring-boot:run
   ```

---

## 5. Viva Questions and Answers (Interview / Defence Guide)

#### Q1: What is the primary role of Google Gemini in this feedback system?
**A**: Google Gemini processes unstructured text feedback from employees and transforms it into structured, quantitative HR diagnostics (sentiment ratings, burnout risk categories, specific topic tags, and actionable managerial recommendations) using strict JSON output formatting.

#### Q2: How does the system handle employee privacy and anonymity?
**A**: When an employee selects the "anonymous" toggle, their name and user ID are fully excluded from the database record associated with reports, ensuring that HR analytics boards can query morale details without deanonymizing the submitter.

#### Q3: Why is sentiment analysis in this project superior to standard word-matching rules?
**A**: LLM-based sentiment models parse semantic context, double-negations, and psychological nuances. For example, the sentence "I do not dislike my team but the tooling is not good" contains double negatives and contrasting clauses that standard rule engines fail to parse correctly, but Gemini easily classifies.

#### Q4: How is the Burnout Risk metric calculated?
**A**: Burnout is projected by looking for specific linguistic cues signaling prolonged fatigue, unresponsive management, unpaid overtime hours, and acute stress. This compiles into a 'low', 'medium', or 'high' risk category.

#### Q5: What is a "Structured JSON Schema" inside Gemini API?
**A**: A structured JSON schema enforces the type, constraints, and required fields of the response payload returning from Gemini, guaranteeing that the server-side parser receives a predictable key-value mapping that will not break database inputs.

#### Q6: How does the platform mitigate the "Denial of Wallet" risk from continuous AI calls?
**A**: Our Express and Spring Boot servers authenticate the caller's JWT token first and perform basic syntax validations before engaging the Gemini SDK, ensuring that unauthorized or spam callers cannot deplete the Gemini API quota.

#### Q7: What is the benefit of using React and Express together on a single port?
**A**: It eliminates complex CORS (Cross-Origin Resource Sharing) configurations and simplifies deployment. The Express server acts as both the API router and static asset host, reducing proxy hops.

#### Q8: How are notifications dispatched when high burnout risk is detected?
**A**: During feedback submission, if the Gemini engine categorizes burnout as 'high', an alert notification record is instantly inserted into the database targeted at the 'hr' group.

#### Q9: What data format is used to export report data in this project?
**A**: The platform supports downloading formatted CSV (Comma-Separated Values) files, compatible with spreadsheet tools like Microsoft Excel and Google Sheets, generated server-side dynamically.

#### Q10: How does the system remain functional if the Google Gemini API key is missing or quota is exhausted?
**A**: The server implements an intelligent, local, rule-based fallback analyzer. If the Gemini call fails, the fallback engine parses keywords and assigns baseline morale indicators, preventing user crashes.
