-- =====================================================================
-- DATABASE SCHEMA: AI-POWERED EMPLOYEE FEEDBACK AGENT FOR HR SUPPORT
-- TARGET ENGINE: MySQL 8.x / MariaDB
-- ACADEMIC USE: Final Year Engineering Project Database Schema Design
-- =====================================================================

CREATE DATABASE IF NOT EXISTS feedforward_db;
USE feedforward_db;

-- ---------------------------------------------------------------------
-- TABLE: department
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS department (
    id VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL UNIQUE,
    manager_name VARCHAR(100) NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_department PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- TABLE: employee
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS employee (
    id VARCHAR(50) NOT NULL,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role VARCHAR(20) NOT NULL DEFAULT 'employee', -- 'employee' | 'hr'
    department_id VARCHAR(50),
    status VARCHAR(20) NOT NULL DEFAULT 'active', -- 'active' | 'inactive'
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_employee PRIMARY KEY (id),
    CONSTRAINT fk_employee_department FOREIGN KEY (department_id) 
        REFERENCES department(id) ON DELETE SET NULL ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Indexes for performance
CREATE INDEX idx_employee_email ON employee(email);
CREATE INDEX idx_employee_department ON employee(department_id);

-- ---------------------------------------------------------------------
-- TABLE: feedback
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS feedback (
    id VARCHAR(50) NOT NULL,
    employee_id VARCHAR(50),
    department_id VARCHAR(50) NOT NULL,
    rating INT NOT NULL CHECK (rating >= 1 AND rating <= 5),
    feedback_text TEXT NOT NULL,
    anonymous BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_feedback PRIMARY KEY (id),
    CONSTRAINT fk_feedback_employee FOREIGN KEY (employee_id) 
        REFERENCES employee(id) ON DELETE SET NULL ON UPDATE CASCADE,
    CONSTRAINT fk_feedback_department FOREIGN KEY (department_id) 
        REFERENCES department(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_feedback_department ON feedback(department_id);
CREATE INDEX idx_feedback_created_at ON feedback(created_at);

-- ---------------------------------------------------------------------
-- TABLE: ai_analysis
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS ai_analysis (
    id VARCHAR(50) NOT NULL,
    feedback_id VARCHAR(50) NOT NULL UNIQUE,
    sentiment VARCHAR(20) NOT NULL, -- 'positive' | 'neutral' | 'negative'
    summary TEXT NOT NULL,
    topics VARCHAR(255) NOT NULL, -- Comma-separated or JSON array representation
    emotion VARCHAR(50) NOT NULL, -- 'happy' | 'sad' | 'stressed' | 'frustrated' | 'motivated' | 'confused'
    burnout_risk VARCHAR(20) NOT NULL, -- 'low' | 'medium' | 'high'
    satisfaction_score INT NOT NULL CHECK (satisfaction_score >= 0 AND satisfaction_score <= 100),
    recommendations TEXT NOT NULL, -- Plaintext or JSON structured action steps
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_ai_analysis PRIMARY KEY (id),
    CONSTRAINT fk_analysis_feedback FOREIGN KEY (feedback_id) 
        REFERENCES feedback(id) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- ---------------------------------------------------------------------
-- TABLE: notification
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS notification (
    id VARCHAR(50) NOT NULL,
    recipient_id VARCHAR(50) NOT NULL, -- Employee ID, 'hr', or 'all'
    title VARCHAR(150) NOT NULL,
    message TEXT NOT NULL,
    is_read BOOLEAN NOT NULL DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_notification PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

CREATE INDEX idx_notification_recipient ON notification(recipient_id);

-- ---------------------------------------------------------------------
-- TABLE: activity_log
-- ---------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS activity_log (
    id VARCHAR(50) NOT NULL,
    user_id VARCHAR(50) NOT NULL,
    user_name VARCHAR(100) NOT NULL,
    action VARCHAR(50) NOT NULL, -- 'LOGIN', 'SUBMIT_FEEDBACK', 'TOGGLE_STATUS', 'VIEW_REPORTS'
    details TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT pk_activity_log PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;


-- =====================================================================
-- SEED DATA SETS: MORALE BASELINE GENERATION
-- =====================================================================

INSERT INTO department (id, name, manager_name, created_at) VALUES
('dept_it', 'Information Technology', 'Sarah Connor', NOW() - INTERVAL 1 YEAR),
('dept_hr', 'Human Resources', 'Michael Scott', NOW() - INTERVAL 1 YEAR),
('dept_mkt', 'Marketing & Sales', 'Harvey Specter', NOW() - INTERVAL 1 YEAR),
('dept_ops', 'Operations & Support', 'Pam Beesly', NOW() - INTERVAL 1 YEAR);

INSERT INTO employee (id, name, email, password_hash, role, department_id, status, created_at) VALUES
('emp_admin', 'HR Admin Director', 'admin@company.com', 'hash_-1182390885', 'hr', 'dept_hr', 'active', NOW() - INTERVAL 6 MONTH),
('emp_1', 'John Doe', 'employee@company.com', 'hash_1603588960', 'employee', 'dept_it', 'active', NOW() - INTERVAL 4 MONTH),
('emp_2', 'Jane Smith', 'jane@company.com', 'hash_1546872295', 'employee', 'dept_mkt', 'active', NOW() - INTERVAL 3 MONTH),
('emp_3', 'Robert Johnson', 'robert@company.com', 'hash_1433290480', 'employee', 'dept_ops', 'active', NOW() - INTERVAL 3 MONTH),
('emp_4', 'Emily Davis', 'emily@company.com', 'hash_1399827400', 'employee', 'dept_it', 'active', NOW() - INTERVAL 2 MONTH);

INSERT INTO feedback (id, employee_id, department_id, rating, feedback_text, anonymous, created_at) VALUES
('fb_1', 'emp_1', 'dept_it', 4, 'I really enjoy working with my current team. The technology stack we are using is very modern and exciting. However, I feel the workload has been quite high recently due to the upcoming launch, making it hard to maintain a perfect work-life balance.', FALSE, NOW() - INTERVAL 45 DAY),
('fb_2', 'emp_2', 'dept_mkt', 5, 'Our manager is exceptional! They always provide clear communication and ensure our achievements are recognized. The career growth path is very well-defined here and I am highly motivated to keep learning.', FALSE, NOW() - INTERVAL 30 DAY),
('fb_3', 'emp_3', 'dept_ops', 2, 'The support infrastructure we are using is very slow and outdated. It crashes frequently and creates immense frustration for operations team members. Customers are unhappy because we cannot solve their tickets on time. We need better tools immediately.', FALSE, NOW() - INTERVAL 25 DAY),
('fb_4', 'emp_4', 'dept_it', 1, 'I am feeling extremely stressed and exhausted. We have been working 12-hour days for the last three weeks with no recognition or compensation adjustments. My manager is unresponsive to my concerns and I feel heavily burnt out. I am seriously considering leaving.', TRUE, NOW() - INTERVAL 15 DAY);

INSERT INTO ai_analysis (id, feedback_id, sentiment, summary, topics, emotion, burnout_risk, satisfaction_score, recommendations, created_at) VALUES
('an_1', 'fb_1', 'positive', 'Employee is highly satisfied with their team and tech stack but notes elevated workloads due to an upcoming launch.', 'Team,Infrastructure,Workload,Work-Life Balance', 'motivated', 'medium', 75, 'Acknowledge effort during launch; Review workload metrics post-launch; Encourage off-days.', NOW() - INTERVAL 45 DAY),
('an_2', 'fb_2', 'positive', 'Employee expresses strong satisfaction with leadership, clear guidance, recognition, and promotional growth.', 'Manager,Communication,Recognition,Career Growth', 'happy', 'low', 95, 'Document Marketing manager practices; Support with development resources; Maintain recognition schemas.', NOW() - INTERVAL 30 DAY),
('an_3', 'fb_3', 'negative', 'Employee is frustrated by slow support software disrupting tickets resolution and operations performance.', 'Infrastructure,Communication', 'frustrated', 'medium', 35, 'Initiate ticketing systems audit; Deliver critical software patches; Consult team on tools replacement.', NOW() - INTERVAL 25 DAY),
('an_4', 'fb_4', 'negative', 'Anonymous employee experiences extreme workload exhaustion and stress with unresponsive manager.', 'Workload,Work-Life Balance,Manager,Recognition,Salary', 'stressed', 'high', 10, 'Address immediate workload emergency; Establish fatigue recovery limits; review manager communication.', NOW() - INTERVAL 15 DAY);

INSERT INTO notification (id, recipient_id, title, message, is_read, created_at) VALUES
('nt_1', 'all', 'Quarterly Feedback Campaign', 'The Q3 feedback cycle is now open. Your honest, anonymous feedbacks help us build a better workspace!', FALSE, NOW() - INTERVAL 10 DAY),
('nt_2', 'hr', 'High Burnout Alert!', 'Attention: Feedback #fb_4 (Anonymous) indicates a High Burnout Risk. Recommended action is required.', FALSE, NOW() - INTERVAL 15 DAY);

INSERT INTO activity_log (id, user_id, user_name, action, details, created_at) VALUES
('al_1', 'emp_1', 'John Doe', 'SUBMIT_FEEDBACK', 'Submitted feedback with ID fb_1', NOW() - INTERVAL 45 DAY),
('al_2', 'emp_2', 'Jane Smith', 'SUBMIT_FEEDBACK', 'Submitted feedback with ID fb_2', NOW() - INTERVAL 30 DAY);
