import fs from 'fs';
import path from 'path';
import { Employee, Department, Feedback, AIAnalysis, Notification, ActivityLog } from './src/types';

const DB_FILE = path.join(process.cwd(), 'db.json');

interface DatabaseSchema {
  employees: Employee[];
  departments: Department[];
  feedbacks: Feedback[];
  ai_analyses: AIAnalysis[];
  notifications: Notification[];
  activity_logs: ActivityLog[];
}

// Helper to hash passwords in a simple, secure, browser-compatible way
export function hashPassword(password: string): string {
  // Simple deterministic string scrambling for demonstration security (simulating spring security / bcrypt)
  let hash = 0;
  for (let i = 0; i < password.length; i++) {
    const char = password.charCodeAt(i);
    hash = (hash << 5) - hash + char;
    hash = hash & hash; // Convert to 32bit integer
  }
  return `hash_${hash}`;
}

// Initial pre-seeded data for high fidelity charts and mock operations
const initialData: DatabaseSchema = {
  departments: [
    { id: 'dept_it', name: 'Information Technology', managerName: 'Sarah Connor', createdAt: new Date(Date.now() - 365 * 24 * 3600 * 1000).toISOString() },
    { id: 'dept_hr', name: 'Human Resources', managerName: 'Michael Scott', createdAt: new Date(Date.now() - 365 * 24 * 3600 * 1000).toISOString() },
    { id: 'dept_mkt', name: 'Marketing & Sales', managerName: 'Harvey Specter', createdAt: new Date(Date.now() - 365 * 24 * 3600 * 1000).toISOString() },
    { id: 'dept_ops', name: 'Operations & Support', managerName: 'Pam Beesly', createdAt: new Date(Date.now() - 365 * 24 * 3600 * 1000).toISOString() }
  ],
  employees: [
    { id: 'emp_admin', name: 'HR Admin Director', email: 'admin@company.com', role: 'hr', departmentId: 'dept_hr', status: 'active', createdAt: new Date(Date.now() - 180 * 24 * 3600 * 1000).toISOString() },
    { id: 'emp_1', name: 'John Doe', email: 'employee@company.com', role: 'employee', departmentId: 'dept_it', status: 'active', createdAt: new Date(Date.now() - 120 * 24 * 3600 * 1000).toISOString() },
    { id: 'emp_2', name: 'Jane Smith', email: 'jane@company.com', role: 'employee', departmentId: 'dept_mkt', status: 'active', createdAt: new Date(Date.now() - 100 * 24 * 3600 * 1000).toISOString() },
    { id: 'emp_3', name: 'Robert Johnson', email: 'robert@company.com', role: 'employee', departmentId: 'dept_ops', status: 'active', createdAt: new Date(Date.now() - 90 * 24 * 3600 * 1000).toISOString() },
    { id: 'emp_4', name: 'Emily Davis', email: 'emily@company.com', role: 'employee', departmentId: 'dept_it', status: 'active', createdAt: new Date(Date.now() - 80 * 24 * 3600 * 1000).toISOString() },
    { id: 'emp_5', name: 'Michael Chang', email: 'michael@company.com', role: 'employee', departmentId: 'dept_it', status: 'inactive', createdAt: new Date(Date.now() - 150 * 24 * 3600 * 1000).toISOString() }
  ],
  feedbacks: [
    {
      id: 'fb_1',
      employeeId: 'emp_1',
      employeeName: 'John Doe',
      departmentId: 'dept_it',
      departmentName: 'Information Technology',
      rating: 4,
      text: 'I really enjoy working with my current team. The technology stack we are using is very modern and exciting. However, I feel the workload has been quite high recently due to the upcoming launch, making it hard to maintain a perfect work-life balance.',
      anonymous: false,
      createdAt: new Date(Date.now() - 45 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'fb_2',
      employeeId: 'emp_2',
      employeeName: 'Jane Smith',
      departmentId: 'dept_mkt',
      departmentName: 'Marketing & Sales',
      rating: 5,
      text: 'Our manager is exceptional! They always provide clear communication and ensure our achievements are recognized. The career growth path is very well-defined here and I am highly motivated to keep learning.',
      anonymous: false,
      createdAt: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'fb_3',
      employeeId: 'emp_3',
      employeeName: 'Robert Johnson',
      departmentId: 'dept_ops',
      departmentName: 'Operations & Support',
      rating: 2,
      text: 'The support infrastructure we are using is very slow and outdated. It crashes frequently and creates immense frustration for operations team members. Customers are unhappy because we cannot solve their tickets on time. We need better tools immediately.',
      anonymous: false,
      createdAt: new Date(Date.now() - 25 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'fb_4',
      employeeId: 'emp_4',
      employeeName: 'Emily Davis',
      departmentId: 'dept_it',
      departmentName: 'Information Technology',
      rating: 1,
      text: 'I am feeling extremely stressed and exhausted. We have been working 12-hour days for the last three weeks with no recognition or compensation adjustments. My manager is unresponsive to my concerns and I feel heavily burnt out. I am seriously considering leaving.',
      anonymous: true,
      createdAt: new Date(Date.now() - 15 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'fb_5',
      employeeId: 'emp_1',
      employeeName: 'John Doe',
      departmentId: 'dept_it',
      departmentName: 'Information Technology',
      rating: 3,
      text: 'Compensation is average. It would be great to have more regular performance evaluations and transparency on promotions. Communication from senior leadership is sparse.',
      anonymous: false,
      createdAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString()
    }
  ],
  ai_analyses: [
    {
      id: 'an_1',
      feedbackId: 'fb_1',
      sentiment: 'positive',
      summary: 'Employee is highly satisfied with their team and tech stack but notes elevated workloads due to an upcoming launch.',
      topics: ['Team', 'Infrastructure', 'Workload', 'Work-Life Balance'],
      emotion: 'motivated',
      burnoutRisk: 'medium',
      satisfactionScore: 75,
      recommendations: [
        'Acknowledge the effort for the upcoming launch in the next team meeting.',
        'Review IT team workload distribution after the launch.',
        'Encourage taking compensatory off-days to restore work-life balance.'
      ],
      createdAt: new Date(Date.now() - 45 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'an_2',
      feedbackId: 'fb_2',
      sentiment: 'positive',
      summary: 'Employee expresses strong satisfaction with their manager, clear communication, recognition, and career growth opportunities.',
      topics: ['Manager', 'Communication', 'Recognition', 'Career Growth'],
      emotion: 'happy',
      burnoutRisk: 'low',
      satisfactionScore: 95,
      recommendations: [
        'Document these leadership best practices from the Marketing manager.',
        'Continue to support the employee with advanced career development resources.',
        'Maintain the current recognition structure.'
      ],
      createdAt: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'an_3',
      feedbackId: 'fb_3',
      sentiment: 'negative',
      summary: 'Employee is frustrated by outdated, crash-prone support software affecting customer ticket resolution and operations performance.',
      topics: ['Infrastructure', 'Communication'],
      emotion: 'frustrated',
      burnoutRisk: 'medium',
      satisfactionScore: 35,
      recommendations: [
        'Schedule an immediate audit of the Operations ticketing systems.',
        'Provide short-term software stability patches or offline procedures.',
        'Schedule a 1-on-1 with Ops team members to align on infrastructure improvements.'
      ],
      createdAt: new Date(Date.now() - 25 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'an_4',
      feedbackId: 'fb_4',
      sentiment: 'negative',
      summary: 'Anonymous employee is highly stressed, working 12-hour days, and experiencing extreme burnout due to unresponsive management and zero recognition.',
      topics: ['Workload', 'Work-Life Balance', 'Manager', 'Recognition', 'Salary'],
      emotion: 'stressed',
      burnoutRisk: 'high',
      satisfactionScore: 10,
      recommendations: [
        'Address immediate workload emergency in the IT department.',
        'Instruct IT managers to implement mandatory fatigue-recovery measures.',
        'Introduce overtime compensation or visible leadership recognition.',
        'Create a safe, supportive feedback channel to discuss workload stress.'
      ],
      createdAt: new Date(Date.now() - 15 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'an_5',
      feedbackId: 'fb_5',
      sentiment: 'neutral',
      summary: 'Employee suggests compensation reviews, clearer promotional transparency, and increased senior leadership updates.',
      topics: ['Salary', 'Promotion', 'Career Growth', 'Communication'],
      emotion: 'confused',
      burnoutRisk: 'low',
      satisfactionScore: 50,
      recommendations: [
        'Share standard salary range benchmarks and grading models during reviews.',
        'Draft and publish a clear career advancement framework document.',
        'Host an all-hands Q&A session with senior leadership.'
      ],
      createdAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString()
    }
  ],
  notifications: [
    {
      id: 'nt_1',
      recipientId: 'all',
      title: 'Quarterly Feedback Campaign',
      message: 'The Q3 feedback cycle is now open. Your honest, anonymous feedbacks help us build a better workspace!',
      read: false,
      createdAt: new Date(Date.now() - 10 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'nt_2',
      recipientId: 'emp_1',
      title: 'AI Feedback Processed',
      message: 'Your recent feedback has been analyzed. View the AI summary and recommendations in your history tab.',
      read: false,
      createdAt: new Date(Date.now() - 5 * 24 * 3600 * 1000).toISOString()
    },
    {
      id: 'nt_3',
      recipientId: 'hr',
      title: 'High Burnout Risk Detected',
      message: 'Attention: Feedback #fb_4 (Anonymous) indicates a High Burnout Risk. Recommended action is required.',
      read: false,
      createdAt: new Date(Date.now() - 15 * 24 * 3600 * 1000).toISOString()
    }
  ],
  activity_logs: [
    { id: 'al_1', userId: 'emp_1', userName: 'John Doe', action: 'SUBMIT_FEEDBACK', details: 'Submitted feedback with ID fb_1', createdAt: new Date(Date.now() - 45 * 24 * 3600 * 1000).toISOString() },
    { id: 'al_2', userId: 'emp_2', userName: 'Jane Smith', action: 'SUBMIT_FEEDBACK', details: 'Submitted feedback with ID fb_2', createdAt: new Date(Date.now() - 30 * 24 * 3600 * 1000).toISOString() },
    { id: 'al_3', userId: 'emp_admin', userName: 'HR Admin Director', action: 'VIEW_REPORTS', details: 'Generated monthly feedback analytics report', createdAt: new Date(Date.now() - 1 * 24 * 3600 * 1000).toISOString() }
  ]
};

// Password storage (separate for safety, simple map)
const PASSWORDS_FILE = path.join(process.cwd(), 'passwords.json');
const initialPasswords: Record<string, string> = {
  'admin@company.com': hashPassword('adminpassword'),
  'employee@company.com': hashPassword('employeepassword'),
  'jane@company.com': hashPassword('janepassword'),
  'robert@company.com': hashPassword('robertpassword'),
  'emily@company.com': hashPassword('emilypassword'),
  'michael@company.com': hashPassword('michaelpassword')
};

// Ensure directories exist and DB is loaded
export function initDB() {
  if (!fs.existsSync(DB_FILE)) {
    fs.writeFileSync(DB_FILE, JSON.stringify(initialData, null, 2));
  }
  if (!fs.existsSync(PASSWORDS_FILE)) {
    fs.writeFileSync(PASSWORDS_FILE, JSON.stringify(initialPasswords, null, 2));
  }
}

export function readDB(): DatabaseSchema {
  initDB();
  const raw = fs.readFileSync(DB_FILE, 'utf-8');
  return JSON.parse(raw);
}

export function writeDB(data: DatabaseSchema) {
  initDB();
  fs.writeFileSync(DB_FILE, JSON.stringify(data, null, 2));
}

export function readPasswords(): Record<string, string> {
  initDB();
  const raw = fs.readFileSync(PASSWORDS_FILE, 'utf-8');
  return JSON.parse(raw);
}

export function writePasswords(passwords: Record<string, string>) {
  initDB();
  fs.writeFileSync(PASSWORDS_FILE, JSON.stringify(passwords, null, 2));
}
