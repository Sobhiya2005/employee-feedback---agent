import express from 'express';
import path from 'path';
import fs from 'fs';
import dotenv from 'dotenv';
import { createServer as createViteServer } from 'vite';
import { GoogleGenAI, Type } from '@google/genai';
import { 
  readDB, 
  writeDB, 
  readPasswords, 
  writePasswords, 
  hashPassword, 
  initDB 
} from './db';
import { Employee, Department, Feedback, AIAnalysis, Notification, ActivityLog, HRDashboardStats } from './src/types';

// Load environment variables
dotenv.config();

const app = express();
const PORT = 3000;

// Body parser middleware
app.use(express.json());

// Initialize Database structure
initDB();

// --- AUTHENTICATION HELPERS ---
// Generates a secure mock token: token_userId_timestamp_role
function generateToken(user: Employee): string {
  const payload = {
    id: user.id,
    role: user.role,
    time: Date.now()
  };
  return Buffer.from(JSON.stringify(payload)).toString('base64');
}

// Middleware to verify Auth token
function authenticateToken(req: express.Request, res: express.Response, next: express.NextFunction) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ message: 'Authentication token required' });
  }

  try {
    const decoded = JSON.parse(Buffer.from(token, 'base64').toString('utf-8'));
    // Token validity: 24 hours
    if (Date.now() - decoded.time > 24 * 60 * 60 * 1000) {
      return res.status(403).json({ message: 'Token has expired' });
    }
    
    // Attach user payload
    req.user = decoded;
    next();
  } catch (error) {
    return res.status(403).json({ message: 'Invalid or malformed token' });
  }
}

// Extend Request type to include user
declare global {
  namespace Express {
    interface Request {
      user?: {
        id: string;
        role: 'employee' | 'hr';
      };
    }
  }
}

// --- GEMINI AI INTEGRATION SERVICE ---
let aiClient: GoogleGenAI | null = null;

function getGeminiClient(): GoogleGenAI | null {
  if (!aiClient) {
    const key = process.env.GEMINI_API_KEY;
    if (!key || key === 'MY_GEMINI_API_KEY') {
      console.warn('GEMINI_API_KEY environment variable is not configured or uses default placeholder.');
      return null;
    }
    aiClient = new GoogleGenAI({
      apiKey: key,
      httpOptions: {
        headers: {
          'User-Agent': 'aistudio-build',
        }
      }
    });
  }
  return aiClient;
}

// Robust fallback analyzer in case Gemini key is missing or fails
function fallbackAIAnalysis(text: string, feedbackId: string): AIAnalysis {
  const lowerText = text.toLowerCase();
  
  // Topic matching
  const topics: string[] = [];
  if (lowerText.includes('salary') || lowerText.includes('compensation') || lowerText.includes('pay') || lowerText.includes('bonus')) topics.push('Salary');
  if (lowerText.includes('workload') || lowerText.includes('stress') || lowerText.includes('overtime') || lowerText.includes('hours') || lowerText.includes('busy')) topics.push('Workload');
  if (lowerText.includes('promote') || lowerText.includes('promotion') || lowerText.includes('growth') || lowerText.includes('career')) topics.push('Career Growth');
  if (lowerText.includes('manager') || lowerText.includes('boss') || lowerText.includes('lead') || lowerText.includes('leadership')) topics.push('Manager');
  if (lowerText.includes('team') || lowerText.includes('colleague') || lowerText.includes('peer') || lowerText.includes('coworker')) topics.push('Team');
  if (lowerText.includes('recognition') || lowerText.includes('appreciate') || lowerText.includes('praise') || lowerText.includes('thank')) topics.push('Recognition');
  if (lowerText.includes('training') || lowerText.includes('learn') || lowerText.includes('skill') || lowerText.includes('course')) topics.push('Training');
  if (lowerText.includes('communication') || lowerText.includes('clear') || lowerText.includes('transparency') || lowerText.includes('meeting')) topics.push('Communication');
  if (lowerText.includes('balance') || lowerText.includes('life') || lowerText.includes('family') || lowerText.includes('vacation')) topics.push('Work-Life Balance');
  if (lowerText.includes('tool') || lowerText.includes('software') || lowerText.includes('hardware') || lowerText.includes('infrastructure') || lowerText.includes('pc') || lowerText.includes('slow')) topics.push('Infrastructure');
  
  if (topics.length === 0) topics.push('General');

  // Sentiment and Emotion
  let sentiment: 'positive' | 'neutral' | 'negative' = 'neutral';
  let emotion: 'happy' | 'sad' | 'stressed' | 'frustrated' | 'motivated' | 'confused' = 'motivated';
  let satisfactionScore = 50;
  let burnoutRisk: 'low' | 'medium' | 'high' = 'low';

  const negativeWords = ['exhausted', 'tired', 'stressed', 'angry', 'terrible', 'worst', 'frustrated', 'burnout', 'burnt out', 'slow', 'fail', 'crash', 'bad', 'disappoint'];
  const positiveWords = ['great', 'excellent', 'love', 'happy', 'enjoy', 'motivation', 'motivated', 'amazing', 'best', 'good', 'success', 'praise', 'recognition'];

  let negCount = 0;
  let posCount = 0;
  negativeWords.forEach(w => { if (lowerText.includes(w)) negCount++; });
  positiveWords.forEach(w => { if (lowerText.includes(w)) posCount++; });

  if (negCount > posCount) {
    sentiment = 'negative';
    satisfactionScore = Math.max(10, 50 - negCount * 12);
    if (lowerText.includes('exhausted') || lowerText.includes('stress') || lowerText.includes('burnout') || lowerText.includes('overtime')) {
      emotion = 'stressed';
      burnoutRisk = negCount > 3 ? 'high' : 'medium';
    } else if (lowerText.includes('slow') || lowerText.includes('crash') || lowerText.includes('frustrat')) {
      emotion = 'frustrated';
      burnoutRisk = 'medium';
    } else {
      emotion = 'sad';
    }
  } else if (posCount > negCount) {
    sentiment = 'positive';
    satisfactionScore = Math.min(95, 60 + posCount * 10);
    emotion = lowerText.includes('learn') || lowerText.includes('career') ? 'motivated' : 'happy';
    burnoutRisk = 'low';
  } else {
    sentiment = 'neutral';
    satisfactionScore = 50;
    emotion = 'confused';
    burnoutRisk = 'low';
  }

  // Recommendations generator
  const recommendations: string[] = [];
  if (topics.includes('Workload') || burnoutRisk === 'high') {
    recommendations.push('Immediate manager contact is recommended to review project deadlines.');
    recommendations.push('Consider offering mental wellbeing sessions or brief vacation rest periods.');
  }
  if (topics.includes('Salary')) {
    recommendations.push('Schedule a regional compensation review meeting or clarify bonus variables.');
  }
  if (topics.includes('Career Growth') || topics.includes('Promotion')) {
    recommendations.push('Outline a detailed 6-12 month skill development plan and career path.');
  }
  if (topics.includes('Infrastructure')) {
    recommendations.push('Initiate IT audit of active systems to replace slow hardware/software.');
  }
  if (topics.includes('Manager')) {
    recommendations.push('Initiate anonymous 360 leadership assessments or manager empathy sessions.');
  }
  if (recommendations.length === 0) {
    recommendations.push('Schedule a routine 1-on-1 progress sync to align expectations.');
  }

  return {
    id: `an_fallback_${Date.now()}`,
    feedbackId,
    sentiment,
    summary: `[Local Analysis] ${text.slice(0, 80)}...`,
    topics,
    emotion,
    burnoutRisk,
    satisfactionScore,
    recommendations,
    createdAt: new Date().toISOString()
  };
}

async function analyzeFeedbackWithAI(text: string, feedbackId: string): Promise<AIAnalysis> {
  const client = getGeminiClient();
  if (!client) {
    console.log('Running robust fallback analysis due to missing Gemini API Client...');
    return fallbackAIAnalysis(text, feedbackId);
  }

  try {
    const prompt = `Analyze this employee feedback and yield structural HR metrics: "${text}"`;
    const response = await client.models.generateContent({
      model: 'gemini-3.5-flash',
      contents: prompt,
      config: {
        systemInstruction: `You are an HR Decision Support AI Agent. Analyze employee feedback and classify metrics.
        Topics checklist: 'Salary', 'Workload', 'Promotion', 'Manager', 'Team', 'Recognition', 'Training', 'Communication', 'Career Growth', 'Work-Life Balance', 'Infrastructure'.
        Sentiment options: 'positive', 'neutral', 'negative'.
        Emotion options: 'happy', 'sad', 'stressed', 'frustrated', 'motivated', 'confused'.
        Burnout risk: 'low', 'medium', 'high'.
        Satisfaction score: number between 0 and 100.
        Recommendations: 2-3 specific, actionable recommendations for HR management.
        Response must strictly follow the responseSchema JSON object layout.`,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sentiment: {
              type: Type.STRING,
              enum: ['positive', 'neutral', 'negative']
            },
            summary: {
              type: Type.STRING,
              description: 'A 1-sentence concise professional summary.'
            },
            topics: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            },
            emotion: {
              type: Type.STRING,
              enum: ['happy', 'sad', 'stressed', 'frustrated', 'motivated', 'confused']
            },
            burnoutRisk: {
              type: Type.STRING,
              enum: ['low', 'medium', 'high']
            },
            satisfactionScore: {
              type: Type.INTEGER
            },
            recommendations: {
              type: Type.ARRAY,
              items: { type: Type.STRING }
            }
          },
          required: ['sentiment', 'summary', 'topics', 'emotion', 'burnoutRisk', 'satisfactionScore', 'recommendations']
        }
      }
    });

    const resultText = response.text;
    if (!resultText) {
      throw new Error('Empty response from Gemini API');
    }

    const parsed = JSON.parse(resultText.trim());
    return {
      id: `an_${Date.now()}`,
      feedbackId,
      sentiment: parsed.sentiment || 'neutral',
      summary: parsed.summary || 'Summary not available.',
      topics: parsed.topics && parsed.topics.length > 0 ? parsed.topics : ['General'],
      emotion: parsed.emotion || 'confused',
      burnoutRisk: parsed.burnoutRisk || 'low',
      satisfactionScore: typeof parsed.satisfactionScore === 'number' ? parsed.satisfactionScore : 50,
      recommendations: parsed.recommendations && parsed.recommendations.length > 0 ? parsed.recommendations : ['Schedule a feedback sync.'],
      createdAt: new Date().toISOString()
    };

  } catch (error) {
    console.error('Gemini API call failed, using high-fidelity fallback analysis instead:', error);
    return fallbackAIAnalysis(text, feedbackId);
  }
}

// --- REST API ENDPOINTS ---

// Health Check
app.get('/api/health', (req, res) => {
  res.json({ status: 'ok', time: new Date().toISOString() });
});

// Authentication: Login
app.post('/api/auth/login', (req, res) => {
  const { email, password } = req.body;
  if (!email || !password) {
    return res.status(400).json({ message: 'Email and password are required' });
  }

  const dbData = readDB();
  const passwords = readPasswords();
  
  const employee = dbData.employees.find(e => e.email === email.toLowerCase());
  if (!employee) {
    return res.status(401).json({ message: 'Invalid credentials. User not found.' });
  }

  if (employee.status !== 'active') {
    return res.status(403).json({ message: 'This employee account is suspended or inactive.' });
  }

  const hashedInput = hashPassword(password);
  if (passwords[email.toLowerCase()] !== hashedInput) {
    return res.status(401).json({ message: 'Invalid credentials. Password incorrect.' });
  }

  // Generate Token
  const token = generateToken(employee);

  // Log active history
  dbData.activity_logs.push({
    id: `al_${Date.now()}`,
    userId: employee.id,
    userName: employee.name,
    action: 'LOGIN',
    details: `User logged in with role: ${employee.role}`,
    createdAt: new Date().toISOString()
  });
  writeDB(dbData);

  res.json({
    user: employee,
    token
  });
});

// Authentication: Register (Employees)
app.post('/api/auth/register', (req, res) => {
  const { name, email, password, departmentId } = req.body;
  if (!name || !email || !password || !departmentId) {
    return res.status(400).json({ message: 'All registration fields are required' });
  }

  const dbData = readDB();
  const passwords = readPasswords();

  if (dbData.employees.some(e => e.email === email.toLowerCase())) {
    return res.status(400).json({ message: 'Email already registered.' });
  }

  const newEmployee: Employee = {
    id: `emp_${Date.now()}`,
    name,
    email: email.toLowerCase(),
    role: 'employee',
    departmentId,
    status: 'active',
    createdAt: new Date().toISOString()
  };

  dbData.employees.push(newEmployee);
  writeDB(dbData);

  passwords[email.toLowerCase()] = hashPassword(password);
  writePasswords(passwords);

  // Push welcome notification
  dbData.notifications.push({
    id: `nt_${Date.now()}`,
    recipientId: newEmployee.id,
    title: 'Welcome to FeedForward!',
    message: `Hello ${name}! Your account in the ${dbData.departments.find(d => d.id === departmentId)?.name || 'Department'} has been created. Feel free to submit secure feedback anytime.`,
    read: false,
    createdAt: new Date().toISOString()
  });
  
  dbData.activity_logs.push({
    id: `al_${Date.now()}`,
    userId: newEmployee.id,
    userName: name,
    action: 'REGISTER',
    details: `Registered as new employee.`,
    createdAt: new Date().toISOString()
  });
  writeDB(dbData);

  const token = generateToken(newEmployee);
  res.status(211).json({
    user: newEmployee,
    token
  });
});

// Authentication: Forgot Password (Mock reset)
app.post('/api/auth/forgot-password', (req, res) => {
  const { email, newPassword } = req.body;
  if (!email || !newPassword) {
    return res.status(400).json({ message: 'Email and new password are required' });
  }

  const dbData = readDB();
  const passwords = readPasswords();

  const employee = dbData.employees.find(e => e.email === email.toLowerCase());
  if (!employee) {
    return res.status(404).json({ message: 'No registered user matches this email.' });
  }

  passwords[email.toLowerCase()] = hashPassword(newPassword);
  writePasswords(passwords);

  dbData.activity_logs.push({
    id: `al_${Date.now()}`,
    userId: employee.id,
    userName: employee.name,
    action: 'PASSWORD_RESET',
    details: `Successfully completed security credential recovery.`,
    createdAt: new Date().toISOString()
  });
  writeDB(dbData);

  res.json({ message: 'Credentials updated successfully. You can now log in.' });
});

// Fetch Departments
app.get('/api/departments', (req, res) => {
  const dbData = readDB();
  res.json(dbData.departments);
});

// Create/Manage Departments (HR only)
app.post('/api/departments', authenticateToken, (req, res) => {
  if (req.user?.role !== 'hr') return res.status(403).json({ message: 'Unauthorized' });
  const { name, managerName } = req.body;
  if (!name || !managerName) return res.status(400).json({ message: 'Department name and manager are required' });

  const dbData = readDB();
  const newDept: Department = {
    id: `dept_${Date.now()}`,
    name,
    managerName,
    createdAt: new Date().toISOString()
  };
  dbData.departments.push(newDept);
  writeDB(dbData);

  res.status(201).json(newDept);
});

// Submit Feedback (Employee only)
app.post('/api/feedbacks', authenticateToken, async (req, res) => {
  const { rating, text, anonymous, departmentId } = req.body;
  if (!rating || !text || !departmentId) {
    return res.status(400).json({ message: 'Rating, feedback text, and department are required' });
  }

  const userId = req.user?.id!;
  const dbData = readDB();

  const employee = dbData.employees.find(e => e.id === userId);
  if (!employee) return res.status(404).json({ message: 'Employee not found.' });

  const department = dbData.departments.find(d => d.id === departmentId);
  const feedbackId = `fb_${Date.now()}`;

  const newFeedback: Feedback = {
    id: feedbackId,
    employeeId: userId,
    employeeName: anonymous ? undefined : employee.name,
    departmentId,
    departmentName: department ? department.name : 'Unknown Department',
    rating: Number(rating),
    text,
    anonymous,
    createdAt: new Date().toISOString()
  };

  dbData.feedbacks.push(newFeedback);
  writeDB(dbData);

  // Trigger server-side AI Gemini Analysis
  const analysis = await analyzeFeedbackWithAI(text, feedbackId);
  dbData.ai_analyses.push(analysis);

  // If High Burnout detected, push alert notifications to HR instantly
  if (analysis.burnoutRisk === 'high') {
    dbData.notifications.push({
      id: `nt_${Date.now()}`,
      recipientId: 'hr',
      title: 'High Burnout Alert!',
      message: `Burnout risk detected as HIGH in a feedback submitted ${anonymous ? 'anonymously' : `by ${employee.name}`} (${department ? department.name : 'IT'}).`,
      read: false,
      createdAt: new Date().toISOString()
    });
  }

  // Push confirmation notification to the employee
  dbData.notifications.push({
    id: `nt_${Date.now()}`,
    recipientId: userId,
    title: 'Feedback Processed',
    message: `Your feedback has been securely analyzed. Sentiment: ${analysis.sentiment.toUpperCase()}. Thank you for helping us improve!`,
    read: false,
    createdAt: new Date().toISOString()
  });

  dbData.activity_logs.push({
    id: `al_${Date.now()}`,
    userId,
    userName: employee.name,
    action: 'SUBMIT_FEEDBACK',
    details: `Submitted feedback. ID: ${feedbackId}, Burnout: ${analysis.burnoutRisk}`,
    createdAt: new Date().toISOString()
  });

  writeDB(dbData);
  res.status(201).json({ feedback: newFeedback, analysis });
});

// Get User Feedback History (Employee)
app.get('/api/feedbacks/my', authenticateToken, (req, res) => {
  const userId = req.user?.id!;
  const dbData = readDB();

  const userFeedbacks = dbData.feedbacks
    .filter(f => f.employeeId === userId)
    .map(f => {
      const analysis = dbData.ai_analyses.find(a => a.feedbackId === f.id);
      return { ...f, analysis };
    })
    .sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  res.json(userFeedbacks);
});

// Get All Feedback with Filters (HR Only)
app.get('/api/feedbacks/all', authenticateToken, (req, res) => {
  if (req.user?.role !== 'hr') {
    return res.status(403).json({ message: 'Unauthorized. HR access required.' });
  }

  const { sentiment, burnoutRisk, departmentId, search } = req.query;
  const dbData = readDB();

  let filtered = dbData.feedbacks.map(f => {
    const analysis = dbData.ai_analyses.find(a => a.feedbackId === f.id);
    return { ...f, analysis };
  });

  if (sentiment) {
    filtered = filtered.filter(f => f.analysis?.sentiment === sentiment);
  }
  if (burnoutRisk) {
    filtered = filtered.filter(f => f.analysis?.burnoutRisk === burnoutRisk);
  }
  if (departmentId) {
    filtered = filtered.filter(f => f.departmentId === departmentId);
  }
  if (search) {
    const s = String(search).toLowerCase();
    filtered = filtered.filter(f => 
      f.text.toLowerCase().includes(s) || 
      (f.employeeName && f.employeeName.toLowerCase().includes(s))
    );
  }

  // Sort descending
  filtered.sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());
  res.json(filtered);
});

// Get HR Dashboard Statistics
app.get('/api/hr/stats', authenticateToken, (req, res) => {
  if (req.user?.role !== 'hr') {
    return res.status(403).json({ message: 'Unauthorized. HR access required.' });
  }

  const dbData = readDB();
  const activeEmployees = dbData.employees.filter(e => e.status === 'active');
  const totalEmployees = activeEmployees.length;
  const totalFeedback = dbData.feedbacks.length;

  // Sentiment counters
  let positive = 0, negative = 0, neutral = 0;
  let totalSatisfy = 0;
  let burnoutCount = 0;

  dbData.ai_analyses.forEach(a => {
    if (a.sentiment === 'positive') positive++;
    else if (a.sentiment === 'negative') negative++;
    else neutral++;

    totalSatisfy += a.satisfactionScore;
    if (a.burnoutRisk === 'high') burnoutCount++;
  });

  const avgSatisfaction = totalFeedback > 0 ? Math.round(totalSatisfy / totalFeedback) : 0;
  const positivePercentage = totalFeedback > 0 ? Math.round((positive / totalFeedback) * 100) : 0;
  const negativePercentage = totalFeedback > 0 ? Math.round((negative / totalFeedback) * 100) : 0;
  const neutralPercentage = totalFeedback > 0 ? Math.round((neutral / totalFeedback) * 100) : 0;

  // Department comparative metrics
  const departmentPerformance = dbData.departments.map(d => {
    const deptFeedbacks = dbData.feedbacks.filter(f => f.departmentId === d.id);
    let satisfySum = 0;
    let counted = 0;

    deptFeedbacks.forEach(f => {
      const an = dbData.ai_analyses.find(a => a.feedbackId === f.id);
      if (an) {
        satisfySum += an.satisfactionScore;
        counted++;
      }
    });

    return {
      departmentId: d.id,
      departmentName: d.name,
      avgSatisfaction: counted > 0 ? Math.round(satisfySum / counted) : 70, // baseline default
      feedbackCount: deptFeedbacks.length
    };
  });

  // Monthly trends (aggregate past 6 months)
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthlyMap: Record<string, { count: number; sum: number }> = {};
  
  // Initialize past 6 months
  for (let i = 5; i >= 0; i--) {
    const d = new Date();
    d.setMonth(d.getMonth() - i);
    const mName = monthNames[d.getMonth()];
    monthlyMap[mName] = { count: 0, sum: 0 };
  }

  dbData.feedbacks.forEach(f => {
    const m = monthNames[new Date(f.createdAt).getMonth()];
    const an = dbData.ai_analyses.find(a => a.feedbackId === f.id);
    if (monthlyMap[m] !== undefined) {
      monthlyMap[m].count++;
      if (an) {
        monthlyMap[m].sum += an.satisfactionScore;
      }
    }
  });

  const monthlyTrends = Object.keys(monthlyMap).map(m => ({
    month: m,
    feedbackCount: monthlyMap[m].count,
    avgSatisfaction: monthlyMap[m].count > 0 ? Math.round(monthlyMap[m].sum / monthlyMap[m].count) : 70
  }));

  // Topic frequencies
  const topicMap: Record<string, number> = {};
  dbData.ai_analyses.forEach(a => {
    a.topics.forEach(t => {
      topicMap[t] = (topicMap[t] || 0) + 1;
    });
  });

  const topIssues = Object.keys(topicMap).map(k => ({
    topic: k,
    count: topicMap[k]
  })).sort((a, b) => b.count - a.count).slice(0, 5);

  const stats: HRDashboardStats = {
    totalEmployees,
    totalFeedback,
    positivePercentage,
    negativePercentage,
    neutralPercentage,
    averageSatisfaction: avgSatisfaction,
    burnoutCount,
    departmentPerformance,
    monthlyTrends,
    topIssues
  };

  res.json(stats);
});

// Notifications: Fetch for current user
app.get('/api/notifications', authenticateToken, (req, res) => {
  const userId = req.user?.id!;
  const userRole = req.user?.role!;
  const dbData = readDB();

  const filtered = dbData.notifications.filter(n => 
    n.recipientId === userId || 
    n.recipientId === 'all' || 
    (n.recipientId === 'hr' && userRole === 'hr')
  ).sort((a, b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime());

  res.json(filtered);
});

// Notifications: Mark as read
app.post('/api/notifications/:id/read', authenticateToken, (req, res) => {
  const { id } = req.params;
  const dbData = readDB();
  
  const notif = dbData.notifications.find(n => n.id === id);
  if (notif) {
    notif.read = true;
    writeDB(dbData);
  }
  res.json({ success: true });
});

// Employee Management: Fetch (HR only)
app.get('/api/employees', authenticateToken, (req, res) => {
  if (req.user?.role !== 'hr') return res.status(403).json({ message: 'Unauthorized' });
  const dbData = readDB();
  res.json(dbData.employees);
});

// Employee Management: Toggle status (HR only)
app.post('/api/employees/:id/toggle', authenticateToken, (req, res) => {
  if (req.user?.role !== 'hr') return res.status(403).json({ message: 'Unauthorized' });
  const { id } = req.params;
  const dbData = readDB();

  const employee = dbData.employees.find(e => e.id === id);
  if (!employee) return res.status(404).json({ message: 'Employee not found.' });

  employee.status = employee.status === 'active' ? 'inactive' : 'active';
  
  dbData.activity_logs.push({
    id: `al_${Date.now()}`,
    userId: req.user?.id!,
    userName: 'HR Administrator',
    action: 'TOGGLE_STATUS',
    details: `Toggled status of employee ${employee.name} to ${employee.status}`,
    createdAt: new Date().toISOString()
  });

  writeDB(dbData);
  res.json(employee);
});

// Activity Logs: Fetch (HR only)
app.get('/api/logs', authenticateToken, (req, res) => {
  if (req.user?.role !== 'hr') return res.status(403).json({ message: 'Unauthorized' });
  const dbData = readDB();
  res.json(dbData.activity_logs.sort((a,b) => new Date(b.createdAt).getTime() - new Date(a.createdAt).getTime()));
});

// --- REPORT EXPORTS ENDPOINTS (CSV/Excel/Print formats) ---
app.get('/api/reports/export/:format', authenticateToken, (req, res) => {
  if (req.user?.role !== 'hr') return res.status(403).json({ message: 'Unauthorized' });
  const { format } = req.params; // csv, excel, or print
  const dbData = readDB();

  const reportRows = dbData.feedbacks.map(f => {
    const a = dbData.ai_analyses.find(an => an.feedbackId === f.id);
    return {
      ID: f.id,
      Date: new Date(f.createdAt).toLocaleDateString(),
      Department: f.departmentName,
      Rating: f.rating,
      Sentiment: a?.sentiment || 'N/A',
      BurnoutRisk: a?.burnoutRisk || 'N/A',
      Satisfaction: a?.satisfactionScore || 0,
      Emotion: a?.emotion || 'N/A',
      FeedbackText: f.text.replace(/"/g, '""')
    };
  });

  if (format === 'csv' || format === 'excel') {
    // Generate simple CSV
    const headers = ['Feedback ID', 'Submission Date', 'Department', 'Rating', 'Sentiment', 'Burnout Risk', 'Satisfaction Score', 'Primary Emotion', 'Feedback Text'];
    const csvContent = [
      headers.join(','),
      ...reportRows.map(row => [
        row.ID,
        row.Date,
        `"${row.Department}"`,
        row.Rating,
        row.Sentiment,
        row.BurnoutRisk,
        row.Satisfaction,
        row.Emotion,
        `"${row.FeedbackText}"`
      ].join(','))
    ].join('\n');

    res.setHeader('Content-Type', 'text/csv');
    res.setHeader('Content-Disposition', `attachment; filename=Employee_Feedback_Report_${Date.now()}.csv`);
    return res.send(csvContent);
  }

  // Printable layout
  res.json(reportRows);
});

// --- VITE MIDDLEWARE & STATIC ASSET PLAYBOOK ---
async function startServer() {
  if (process.env.NODE_ENV !== 'production') {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`AI Feedback Agent server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
